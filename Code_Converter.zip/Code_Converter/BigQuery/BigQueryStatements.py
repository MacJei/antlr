import re
import util
from antlr4 import *
from BigQuery.parser.bigqueryLexer import bigqueryLexer
from BigQuery.parser.bigqueryListener import bigqueryListener
from BigQuery.parser.bigqueryParser import bigqueryParser
from BigQuery.parser.XxbigqueryListener import XxbigqueryListener
from BigQuery.parser.XxErrorListener import BigqueryErrorListener


class BigQueryStatements():
    def __init__(self, text):
        self.original_text = text
        self.text = text
        self.cnv_code = ''

    def convStatement(self, cnv_ds):
        #check conversion context
        sig = self.scopeCheckChange(cnv_ds)
        if sig == 'go':
            cnv_code = self.toAthena(cnv_ds)
        if sig == 'nogo':
            cnv_ds.cntx.logger.add_log('INFO', 'Skipping out of scope statement')
            cnv_ds.cntx.logger.add_log_details(self.text)
            cnv_code = ''
        return cnv_code
        
    def replaceOperator(self, cnv_ds, cond_str):
        pass
        
    def replaceVariables(self, cnv_ds, stmt, quote = True):
        pass
        
    def scopeCheckChange(self, cnv_ds):
        return 'go'
        

class CreateReplaceView(BigQueryStatements):
    def __init__(self, text):
        super().__init__(text)
    
    def toAthena(self, cnv_ds):        
        cnv_code = ''
        stmt =  self.text
        
        try:
            if re.search(r'\bIF\s+NOT\s+EXISTS\b', stmt, re.S|re.I):
                cnv_ds.cntx.logger.add_log('WARN', 'CREATE VIEW IF NOT EXISTS clause not supported. Changing to CREATE VIEW statement.')
                stmt = re.sub(r'\bIF\s+NOT\s+EXISTS\s+', '', stmt, flags=re.S|re.I)
                cnv_ds.cntx.logger.add_log_details(stmt)
            
            #get view name             
            re_match = re.search(r'^(CREATE\s+(?:OR\s+REPLACE\s+)?)VIEW\s+`?([\w\.]+)`?', stmt, re.S|re.I)
            if re_match:
                view_cmd = re_match.group(1).strip()
                view_name = re_match.group(2).strip('`')
            else:
                raise Exception('Unable to get view name from source script.')
            #print(view_name)
                    
            #get view select statement
            view_select_sql = re.search(r'\bSELECT\b.*', stmt, re.S|re.I).group().strip()
            #print(view_select_sql)        
            
            if view_select_sql[-1] != ';':
                view_select_sql += ';'
            
            #Antlr Parse
            try:        
                lexer = bigqueryLexer(InputStream(view_select_sql))
                lexer.removeErrorListeners()
                stream = CommonTokenStream(lexer)
                parser = bigqueryParser(stream)
                parser.removeErrorListeners()
                parser.addErrorListener(BigqueryErrorListener())
                tree = parser.query_statement()
                lsnr = XxbigqueryListener(stream, cnv_ds.cntx.logger)
                walker = ParseTreeWalker()
                walker.walk(lsnr, tree)
            except Exception as e:
                cnv_ds.cntx.logger.add_log('ERROR', 'Failed to parse view select statement.')
                cnv_ds.cntx.logger.add_log_details('Syntax error: ' + str(e))
                cnv_ds.cntx.logger.add_log('WARN', 'Using unparsed view select statement. Result may be iscosistant.')
            else:
                cnv_ds.cntx.logger.add_log('INFO', 'Script contect parse completed.')
                view_select_sql = lsnr.out_sql
    
            cnv_code = view_cmd + ' view ' + view_name + '\nas\n' + view_select_sql
    
            print(cnv_code)
        
        except Exception as e:
            cnv_ds.cntx.logger.add_log('ERROR', e.__str__())
            
        
        return cnv_code