from Teradata.TeradataScript import *
from Teradata.TeradataConvert import *