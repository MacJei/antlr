#Import packages
import os
import re
import sys
import yaml
import boto3
import logging
from global_settings import *
from ss_inblt_func import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import SQLContext
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame
from pyspark.context import SparkContext
from pyspark.context import SparkConf
from datetime import datetime
from pyspark.sql.functions import lit
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DecimalType, TimestampType, FloatType, DateType

def usp_updatemastercontractlookup(loadcontrolid):

    #audit logging
    starttime = datetime.now()
    log_filename = 'logfile' + starttime.strftime('%Y-%m-%d-%H-%M-%S')+'.log'
    logging.basicConfig(filename=log_filename,level=logging.DEBUG)
    logging.getLogger('py4j').setLevel(logging.ERROR)
    logging.getLogger('botocore').setLevel(logging.ERROR)
    logging.getLogger('boto3').setLevel(logging.ERROR)
    logging.getLogger('matplotlib').setLevel(logging.ERROR)
    logging.getLogger('pyspark').setLevel(logging.ERROR)
    logging.debug('Running Audit Log')

    sc = SparkContext()
    sc.setLogLevel('ERROR')
    spark = SparkSession(sc)
    sqlContext = SQLContext(sc)
    sqlContext.setConf('spark.sql.parquet.compression.codec','snappy')

    try:
        db_tables_dict = {'lookup.mastercontract':'lookup__mastercontract__df',
        'icmtrans_peacetx.vw_mastercontractlookup':'icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df',
        'icmstage_peacetx.pm_e_consprem_tb':'icm_stage__icmstage_peacetx__pm_e_consprem_tb__df',
        'icmtrans_peacetx.vw_mastercontractlookup':'icmtrans_peacetx__vw_mastercontractlookup__df',
        'icmstage_peacetx.pm_e_consprem_tb':'icmstage_peacetx__pm_e_consprem_tb__df',
        'icmstage_peacetx.pm_e_consprem_tb_temp':'icmstage_peacetx__pm_e_consprem_tb_temp__df'}

        for table,df in db_tables_dict.items():
            if df not in mod_df.keys():
                tab__df = spark.read.parquet('s3://' + s3_source_bucket + table)
                org_df[df] = tab__df
                mod_df[df] = tab__df
                mod_df[df].createOrReplaceTempView(df)
    except:
        raise
        #quit()

    
    df_col_list = mod_df['icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df'].columns
    df_col_list_str = ('lkp.') + (',lkp.').join(df_col_list)
    upd_col_dict = {'lkp.loadcontroldeleteid': '{}.format(loadcontrolid) as lkp.loadcontroldeleteid'}
    
    for col in upd_col_dict.keys():
        df_col_list_str = df_col_list_str.replace(col,upd_col_dict[col])
    
    icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df_1 = spark.sql("""select lkp.* 
     from icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df lkp 
    	left	join (
    			select	cdpt.debtornum,
    				cdpt.premnum,
    				cdpt.supplyreqdate
    			from	icm_stage__icmstage_peacetx__pm_e_consprem_tb__df cdpt
    			group by
    				cdpt.debtornum,
    				cdpt.premnum,
    				cdpt.supplyreqdate
    		) as cdpt
    		on	lkp.debtornum = cdpt.debtornum
    		and	lkp.premnum = cdpt.premnum
    		and	lkp.supplyreqdate = cdpt.supplyreqdate 
     where cdpt.debtornum		is null
    	  and	lkp.loadcontroldeleteid	is null""")
    
    icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df_2 = spark.sql("select " + df_col_list_str + """from icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df lkp 
    	left	join (
    			select	cdpt.debtornum,
    				cdpt.premnum,
    				cdpt.supplyreqdate
    			from	icm_stage__icmstage_peacetx__pm_e_consprem_tb__df cdpt
    			group by
    				cdpt.debtornum,
    				cdpt.premnum,
    				cdpt.supplyreqdate
    		) as cdpt
    		on	lkp.debtornum = cdpt.debtornum
    		and	lkp.premnum = cdpt.premnum
    		and	lkp.supplyreqdate = cdpt.supplyreqdate 
    where cdpt.debtornum		is null
    	  and	lkp.loadcontroldeleteid	is null""")
    
    mod_df['icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df'] = mod_df['icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df'].subtract(icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df_1).union(icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df_2)
    mod_df['icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df'].createOrReplaceTempView('icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df')
    rowcount_df = icm_stage__icmtrans_peacetx__vw_mastercontractlookup__df_2
    
    
    try:
    
        df_col_list = mod_df['icmtrans_peacetx__vw_mastercontractlookup__df'].columns
        df_col_list_str = ('a.') + (',a.').join(df_col_list)
        upd_col_dict = {'a.changed': '1 as changed', 'a.loadcontrolupdateid': 'b.loadcontrolcreateid as a.loadcontrolupdateid', 'a.loadcontroldeleteid': 'null as a.loadcontroldeleteid'}
        
        for col in upd_col_dict.keys():
            df_col_list_str = df_col_list_str.replace(col,upd_col_dict[col])
        
        icmtrans_peacetx__vw_mastercontractlookup__df_1 = spark.sql("""select a.* 
         from icmtrans_peacetx__vw_mastercontractlookup__df a 
        		inner	join icmstage_peacetx__pm_e_consprem_tb_temp__df b 
        			on	a.debtornum = b.debtornum
        			and	a.premnum = b.premnum
        			and	a.supplyreqdate = b.supplyreqdate 
         where a.cis_id	= 1  
        		  and	a.changed	= 0""")
        
        icmtrans_peacetx__vw_mastercontractlookup__df_2 = spark.sql("select " + df_col_list_str + """from icmtrans_peacetx__vw_mastercontractlookup__df a 
        		inner	join icmstage_peacetx__pm_e_consprem_tb_temp__df b 
        			on	a.debtornum = b.debtornum
        			and	a.premnum = b.premnum
        			and	a.supplyreqdate = b.supplyreqdate 
        where a.cis_id	= 1  
        		  and	a.changed	= 0""")
        
        mod_df['icmtrans_peacetx__vw_mastercontractlookup__df'] = mod_df['icmtrans_peacetx__vw_mastercontractlookup__df'].subtract(icmtrans_peacetx__vw_mastercontractlookup__df_1).union(icmtrans_peacetx__vw_mastercontractlookup__df_2)
        mod_df['icmtrans_peacetx__vw_mastercontractlookup__df'].createOrReplaceTempView('icmtrans_peacetx__vw_mastercontractlookup__df')
        rowcount_df = icmtrans_peacetx__vw_mastercontractlookup__df_2
        
        if not exists (
        			select	*
        			from	lookup.mastercontract
        			where	cis_id		== 1
        		):
            
        else:
            
        irowsupdated = rowcount_df.count()
    
    except Exception as e:
    
        
        
        
        errormessage = str(spark.sql("""select error_message(),
        			{} = error_severity(),
        			{} = error_state()""".format(errorseverity, errorstate)).collect()[0][0])
        
        raise
        


#Write modified data frames to target
if __name__ == '__main__':
    usp_updatemastercontractlookup (*sys.argv[1:])
    try:
        for tab_df in mod_df.keys():
            if mod_df[tab_df] == org_df[tab_df]:
                continue
            target_table = re.search(r'\w*\.?\w+$', tab_df.replace('__df','').replace('__', '.'), re.M).group()
            mod_df[tab_df].write.mode('overwrite').parquet('s3://' + target_bucket + target_table)
    except:
        raise

