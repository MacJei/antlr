import re
import util
import BigQuery.BigQueryStatements as bqs

#BigQuery script class
class View():

    def __init__(self, cntx, fname):
        self.cntx = cntx
        self.fname = fname
        try:
            self.text = self.readScript()
            self.statements = self.loadStatements()
        except:
            raise
            
    #reads script content and prepare for parsing
    def readScript(self):
        
        #reading script contect
        self.cntx.logger.add_log('INFO', 'Reading script content')
        file_path = self.cntx.source_dir+'\\'+self.fname
                
        with open(file_path,'r') as f:
            script_text = f.read()
        self.cntx.logger.add_log('INFO', 'Number of lines are ' + str(script_text.count('\n')))
        
        #removing comment lines    
        self.cntx.logger.add_log('INFO', 'Removing comment lines from script content')
        script_text = re.sub(r'/\*.*?\*/', '', script_text, flags = re.S)               #remove comment with /* */
        script_text = re.sub(r'--.*?(\r?\n)', r'\1', script_text)                       #remove comment with --
        script_text = re.sub(r'((\r?\n)[ \t]*){2,}', r'\1', script_text)                #remove blank lines
        #check for error
        if ('/*' in script_text) or ('*/' in script_text) or ('--' in script_text):
            self.cntx.logger.add_log('ERROR', 'Unable to remove comments from script content')
        
        #changing script content to lower case
        try:
            self.cntx.logger.add_log('INFO', 'Changing script content to lower case.')
            script_text = util.newLower(script_text)
        except Exception as e:
            self.cntx.logger.add_log('ERROR', 'Encountered error while changing script content to lower case.')
            self.cntx.logger.add_log_details(str(e))
        
        return script_text 


    #parse script content and split into statement objects
    def loadStatements(self):
        
        script_text = self.text
        statement_objs = []
        
        #split file content
        try:    
            self.cntx.logger.add_log('INFO', 'Splitting script content into individual statements based on semi-colon.')
            script_statements = util.newSplit(script_text, ';')
        except:
            raise Exception('Splitting script content into statement list failed.')
    
        self.cntx.logger.add_log('INFO', 'Identiying statements in scope of the converter')
        for stmt in script_statements:
            stmt = stmt.strip()
            if len(stmt) > 0:   

                if re.search(r'^CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+', stmt, re.S|re.I):
                    stmt_obj = bqs.CreateReplaceView(stmt)
                    statement_objs.append(stmt_obj)
                    
                else:
                    self.cntx.logger.add_log('WARN','Statement skipped. Not Supported.')
                    self.cntx.logger.add_log_details(stmt)
                    
        return statement_objs