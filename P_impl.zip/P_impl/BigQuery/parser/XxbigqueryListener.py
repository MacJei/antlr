from antlr4 import *
from BigQuery.parser.bigqueryLexer import bigqueryLexer
from BigQuery.parser.bigqueryListener import bigqueryListener
from BigQuery.parser.bigqueryParser import bigqueryParser
from antlr4.tree.Tree import TerminalNodeImpl
import BigQuery.parser.XxfunctionConverter as Bq2Athena
import datetime
import sys
import re


class XxbigqueryListener(bigqueryListener):
    def __init__(self,tokens:CommonTokenStream, logger):
        #logging
        self.logger = logger

        #function
        self.fn_nest_cnt = 0
        self.fn_tokens = []
        self.fn_spaces = []
        self.fn_exprns = [] ##
        self.fn_conv_txt = {}
        
        #table expr
        self.in_table_expr = False
        
        #common
        self.token_stream = tokens.tokens
        self.out_sql = ''


    #OVERLOADED: Generic Terminal Handler
    def visitTerminal(self, ctx:TerminalNodeImpl):
        if self.fn_nest_cnt == 0 and self.in_table_expr == False:  
            tok_txt = ctx.getText()
            hdn_tok = self.getLeftHiddenToken(ctx)
            if tok_txt != '<EOF>':
                self.out_sql += hdn_tok + tok_txt

    def enterExpr_Function_Generic(self, ctx:bigqueryParser.Expr_Function_GenericContext):
        self.enterFunction(ctx)

    def exitExpr_Function_Generic(self, ctx:bigqueryParser.Expr_Function_GenericContext):
        self.exitFunction(ctx)

    def enterExpr_Cast(self, ctx:bigqueryParser.Expr_CastContext):
        self.enterFunction(ctx)

    def exitExpr_Cast(self, ctx:bigqueryParser.Expr_CastContext):
        self.exitFunction(ctx)

    def enterExpr_Case(self, ctx:bigqueryParser.Expr_CaseContext):
        self.enterFunction(ctx)

    def exitExpr_Case(self, ctx:bigqueryParser.Expr_CaseContext):
        self.exitFunction(ctx)

    def enterTable_expr(self, ctx:bigqueryParser.Table_exprContext):
        if ctx.getChild(0).getText() == '`':
            self.in_table_expr = True

    def exitTable_expr(self, ctx:bigqueryParser.Table_exprContext):
        if ctx.getChild(0).getText() != '`':
            child_count = ctx.getChildCount()
            if child_count == 5:
                dataset_nm = ctx.getChild(2).getText()
                table_nm = ctx.getChild(4).getText()                
                #self.out_sql += ' ' + dataset_nm + '.' + table_nm
                self.out_sql += ' ' + table_nm
            elif child_count == 3:
                dataset_nm = ctx.getChild(0).getText()
                table_nm = ctx.getChild(2).getText()
                #self.out_sql += ' ' + dataset_nm + '.' + table_nm
                self.out_sql += ' ' + table_nm    
            elif child_count == 1:
                table_nm = ctx.getChild(0).getText()
                self.out_sql += ' ' + table_nm    
            else:
                self.logger.add_log('WARN', 'Unable to recognise table expression ' + ctx.getText())
                self.out_sql += ' ' + ctx.getText()

        if ctx.getChild(0).getText() == '`':                
            self.in_table_expr = False
                
        
    #LOCAL: Generic Tasks on Function entry/Exit
    def enterFunction(self, ctx):
        self.fn_nest_cnt += 1

    def exitFunction(self, ctx):
        self.fn_nest_cnt -= 1

        self.fn_tokens = []
        self.fn_spaces = []
        self.walkFunctionExpr(ctx)
        #print(self.fn_tokens)
        fn_new_str = Bq2Athena.convert(self.fn_tokens, self.fn_spaces, self.logger)
        if self.fn_nest_cnt == 0 :
            self.out_sql += fn_new_str
            self.fn_conv_txt[str(ctx.getSourceInterval()[0])] = fn_new_str.strip()
        else:
            self.fn_conv_txt[str(ctx.getSourceInterval()[0])] = fn_new_str.strip()

    def walkFunctionExpr(self, ctx):
        for child in ctx.getChildren():
            if isinstance(child, TerminalNodeImpl):
                tok_txt = child.getText()
                self.fn_tokens.append(tok_txt)
                hdn_tok = self.getLeftHiddenToken(child)
                self.fn_spaces.append(hdn_tok)
                #return hdn_tok+tok_txt##
            #check if expr is function or cast
            elif isinstance(child, bigqueryParser.Expr_Function_GenericContext) or isinstance(child,bigqueryParser.Expr_CastContext):
                self.fn_tokens.append(self.fn_conv_txt[str(child.getSourceInterval()[0])])
                hdn_tok = self.getLeftHiddenToken(child)
                self.fn_spaces.append(hdn_tok)
            else:
                self.walkFunctionExpr(child)

    #LOCAL: Generic Task
    def getLeftHiddenToken(self,ctx):
        tok_pos = ctx.getSourceInterval()[0]
        hdn_tok = ''
        while tok_pos > 0 and self.token_stream[tok_pos - 1].channel == 1:
            hdn_tok = self.token_stream[tok_pos - 1].text + hdn_tok
            tok_pos -= 1
        return hdn_tok