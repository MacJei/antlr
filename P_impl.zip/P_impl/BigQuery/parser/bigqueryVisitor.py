# Generated from bigquery.g4 by ANTLR 4.7.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .bigqueryParser import bigqueryParser
else:
    from bigqueryParser import bigqueryParser

# This class defines a complete generic visitor for a parse tree produced by bigqueryParser.

class bigqueryVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by bigqueryParser#query_statement.
    def visitQuery_statement(self, ctx:bigqueryParser.Query_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#query_expr.
    def visitQuery_expr(self, ctx:bigqueryParser.Query_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#select_statement.
    def visitSelect_statement(self, ctx:bigqueryParser.Select_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#from_statement.
    def visitFrom_statement(self, ctx:bigqueryParser.From_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#from_item.
    def visitFrom_item(self, ctx:bigqueryParser.From_itemContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#where_statement.
    def visitWhere_statement(self, ctx:bigqueryParser.Where_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#group_statement.
    def visitGroup_statement(self, ctx:bigqueryParser.Group_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#having_statement.
    def visitHaving_statement(self, ctx:bigqueryParser.Having_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#order_clause.
    def visitOrder_clause(self, ctx:bigqueryParser.Order_clauseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#limit_clause.
    def visitLimit_clause(self, ctx:bigqueryParser.Limit_clauseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#unary_operator.
    def visitUnary_operator(self, ctx:bigqueryParser.Unary_operatorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Case.
    def visitExpr_Case(self, ctx:bigqueryParser.Expr_CaseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Unary.
    def visitExpr_Unary(self, ctx:bigqueryParser.Expr_UnaryContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_In.
    def visitExpr_Bool_In(self, ctx:bigqueryParser.Expr_Bool_InContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Binary2.
    def visitExpr_Binary2(self, ctx:bigqueryParser.Expr_Binary2Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Binary1.
    def visitExpr_Binary1(self, ctx:bigqueryParser.Expr_Binary1Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Number.
    def visitExpr_Number(self, ctx:bigqueryParser.Expr_NumberContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_Is.
    def visitExpr_Bool_Is(self, ctx:bigqueryParser.Expr_Bool_IsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Relational.
    def visitExpr_Relational(self, ctx:bigqueryParser.Expr_RelationalContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_String.
    def visitExpr_String(self, ctx:bigqueryParser.Expr_StringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Function_Generic.
    def visitExpr_Function_Generic(self, ctx:bigqueryParser.Expr_Function_GenericContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_And.
    def visitExpr_Bool_And(self, ctx:bigqueryParser.Expr_Bool_AndContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bracketed.
    def visitExpr_Bracketed(self, ctx:bigqueryParser.Expr_BracketedContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Arrow.
    def visitExpr_Arrow(self, ctx:bigqueryParser.Expr_ArrowContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Cast.
    def visitExpr_Cast(self, ctx:bigqueryParser.Expr_CastContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Keyword.
    def visitExpr_Keyword(self, ctx:bigqueryParser.Expr_KeywordContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_Pipe.
    def visitExpr_Bool_Pipe(self, ctx:bigqueryParser.Expr_Bool_PipeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Interval.
    def visitExpr_Interval(self, ctx:bigqueryParser.Expr_IntervalContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_Caret.
    def visitExpr_Bool_Caret(self, ctx:bigqueryParser.Expr_Bool_CaretContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Dql.
    def visitExpr_Dql(self, ctx:bigqueryParser.Expr_DqlContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Column.
    def visitExpr_Column(self, ctx:bigqueryParser.Expr_ColumnContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_Or.
    def visitExpr_Bool_Or(self, ctx:bigqueryParser.Expr_Bool_OrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Expr_Bool_Amp.
    def visitExpr_Bool_Amp(self, ctx:bigqueryParser.Expr_Bool_AmpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Case_Switched.
    def visitCase_Switched(self, ctx:bigqueryParser.Case_SwitchedContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#Case_Searched.
    def visitCase_Searched(self, ctx:bigqueryParser.Case_SearchedContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#switch_section.
    def visitSwitch_section(self, ctx:bigqueryParser.Switch_sectionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#switch_search_condition_section.
    def visitSwitch_search_condition_section(self, ctx:bigqueryParser.Switch_search_condition_sectionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#interval_delta.
    def visitInterval_delta(self, ctx:bigqueryParser.Interval_deltaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#cast_expr.
    def visitCast_expr(self, ctx:bigqueryParser.Cast_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#column_expr.
    def visitColumn_expr(self, ctx:bigqueryParser.Column_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#except_statement.
    def visitExcept_statement(self, ctx:bigqueryParser.Except_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#replace_statement.
    def visitReplace_statement(self, ctx:bigqueryParser.Replace_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#join_type.
    def visitJoin_type(self, ctx:bigqueryParser.Join_typeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#on_clause.
    def visitOn_clause(self, ctx:bigqueryParser.On_clauseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#set_op.
    def visitSet_op(self, ctx:bigqueryParser.Set_opContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#using_clause.
    def visitUsing_clause(self, ctx:bigqueryParser.Using_clauseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#bool_expression.
    def visitBool_expression(self, ctx:bigqueryParser.Bool_expressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#count.
    def visitCount(self, ctx:bigqueryParser.CountContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#skip_rows.
    def visitSkip_rows(self, ctx:bigqueryParser.Skip_rowsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#with_statement.
    def visitWith_statement(self, ctx:bigqueryParser.With_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#name.
    def visitName(self, ctx:bigqueryParser.NameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#alias_name.
    def visitAlias_name(self, ctx:bigqueryParser.Alias_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#column_name.
    def visitColumn_name(self, ctx:bigqueryParser.Column_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#cte_name.
    def visitCte_name(self, ctx:bigqueryParser.Cte_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#dataset_name.
    def visitDataset_name(self, ctx:bigqueryParser.Dataset_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#datatype_name.
    def visitDatatype_name(self, ctx:bigqueryParser.Datatype_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#function_name.
    def visitFunction_name(self, ctx:bigqueryParser.Function_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#join_name.
    def visitJoin_name(self, ctx:bigqueryParser.Join_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#project_name.
    def visitProject_name(self, ctx:bigqueryParser.Project_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#table_name.
    def visitTable_name(self, ctx:bigqueryParser.Table_nameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#table_expr.
    def visitTable_expr(self, ctx:bigqueryParser.Table_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#number.
    def visitNumber(self, ctx:bigqueryParser.NumberContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#integer_type.
    def visitInteger_type(self, ctx:bigqueryParser.Integer_typeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#float_type.
    def visitFloat_type(self, ctx:bigqueryParser.Float_typeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#string.
    def visitString(self, ctx:bigqueryParser.StringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#quoted_string.
    def visitQuoted_string(self, ctx:bigqueryParser.Quoted_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#triple_quoted_string.
    def visitTriple_quoted_string(self, ctx:bigqueryParser.Triple_quoted_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#raw_string.
    def visitRaw_string(self, ctx:bigqueryParser.Raw_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#byte_string.
    def visitByte_string(self, ctx:bigqueryParser.Byte_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#raw_byte_string.
    def visitRaw_byte_string(self, ctx:bigqueryParser.Raw_byte_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#special_string.
    def visitSpecial_string(self, ctx:bigqueryParser.Special_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by bigqueryParser#keyword.
    def visitKeyword(self, ctx:bigqueryParser.KeywordContext):
        return self.visitChildren(ctx)



del bigqueryParser