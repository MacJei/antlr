import re

def convert(tknList = [], spsList = [], logger = None):
    
    td_fnctn_map = {
        #Change Functions
        'CAST':     CAST,
        'SUBSTR':   SUBSTR,
        #No Change Functions
        'AVG':      'SAME',
        'MIN':      'SAME',
        'MAX':      'SAME',
        'SUM':      'SAME',
        'CONCAT':   'SAME'
    }

    #[TEMP_FIX] to add spaces in CASE statement 
    tknList = alterTknList(tknList)
    out_str = ''
    if td_fnctn_map.get(tknList[0].upper()) is None:  #####Out of scope - function call
        for i in range(len(tknList)):
            out_str += spsList[i] + tknList[i]
        #Log WARN for out of scope functions
        logger.add_log('WARN',tknList[0] + ' Function is not covered in scope and has been kept AS IS in target code. Consider manual reconstruction if necessary.')
        logger.add_log_details(out_str.strip())
        return out_str
    else:
        fnctn = td_fnctn_map[tknList[0].upper()]
        if fnctn == 'SAME':                            #####AS IS in target - function call
            for i in range(len(tknList)):
                out_str += spsList[i] + tknList[i]
            # Log INFO for AS IS functions
            logger.add_log('INFO', tknList[0] + ' Function call is same in Target language, hence not converted.')
            logger.add_log_details(out_str.strip())
            return out_str
        else:                                           #####Requires conversion - function call
            ret_result = fnctn(tknList, spsList, logger)
            if ret_result[0:5].lower() == 'error':
                logger.add_log('ERROR', tknList[0] + ' Function could not be converted. Consider manual reconstruction.' + ret_result[6:])
                for i in range(len(tknList)):
                    out_str += spsList[i] + tknList[i]
                logger.add_log_details(out_str.strip())
                return out_str
            else:
                #lpad = spsList[0]
                return ret_result #lpad + ret_result

def alterTknList(tknList):
    alt_tknList = []
    for tkn in tknList:
        if tkn.upper() in ['CASE','WHEN','THEN','ELSE','END']:
            alt_tkn = ' ' + tkn + ' '
            alt_tknList.append(alt_tkn)
        else:
            alt_tknList.append(tkn)
    return alt_tknList


def CAST(tknList, spsList, logger):
    tknList_upr = [tkn.upper() for tkn in tknList]
    out_str = ''

    idx_as = tknList_upr.index('AS')
    cast_expr = ''.join(tknList[2:idx_as])
    #print(cast_expr)

    idx_typ = idx_as + 1
    cast_type = tknList[idx_typ]

    data_type_switch = {
        'INT64': 'BIGINT',
        'NUMERIC': 'DECIMAL(38,9)',
        'FLOAT64': 'DOUBLE',
        'BOOL': 'BOOLEAN',
        'STRING': 'VARCHAR',
        'BYTES': 'VARBINARY'
    }
    if cast_type.upper() in data_type_switch.keys():
        for i in range(0,len(tknList)):
            if i in (0,1,idx_as,len(tknList)-1):  #Keywords and brackets intact
                out_str += spsList[i] + tknList[i]
            elif i == idx_typ:
                out_str += spsList[i] + data_type_switch.get(tknList[i].upper())
            else:
                out_str += spsList[i] + tknList[i]
    elif cast_type.upper() == 'DATE':
        out_str = spsList[0] + 'date_parse(' + cast_expr + ',\'%Y-%m-%d\'' + ')'
    elif cast_type.upper() == 'DATETIME':
        out_str = spsList[0] + 'date_parse(' + cast_expr + ',\'%Y-%m-%d %H:%i:%s.%f\'' + ')'
    else:
        return 'Error: Unsupported Data Type'
    return out_str


def SUBSTR(tknList, spsList, logger):
    x = newSplitArr(tknList[2:-1], ',')
    out_str = ''
    if len(x) < 3:
        return 'Error: 3 parameters Mandatory.'
    else:
        for i in range(len(tknList)):
            out_str += spsList[i] + tknList[i]
        logger.add_log('INFO', tknList[0] + ' Function call is same in Target language, hence not converted.')
        logger.add_log_details(out_str.strip())
        return out_str


#GENERIC utility Functions
#custom split function that ignores if given delimeter is within () or ''
def newSplitArr(sql_str, dl):
    in_bracket = 0        #indicates if current caracter is within circular bracket
    in_quote = 0          #indicates if current caracter is within quote
    split_cache = []      #current split element cache
    split_arr = []       #result array

    for ch in sql_str:
        if ch == '(' :      #update in_bracket value if '(' not in quote
            if in_quote == 0:
                in_bracket = in_bracket + 1
            split_cache.append(ch) #add character into split cache
        elif ch == ')':     #update in_bracket value if ')' not in quote
            if in_quote == 0:
                in_bracket = in_bracket - 1
            #add character into split cache
            split_cache.append(ch)
        #update in_quote value based on whether single quote found before
        elif ch == "'":
            if in_quote == 0:
                in_quote = in_quote + 1
            else:
                in_quote = in_quote - 1
            #add character into split cache
            split_cache.append(ch)
        #if given delimeter found
        elif ch == dl:
            #if delimeter not in circular bracket or single quote
            if in_bracket == 0 and in_quote == 0:
                #move split cache content to split array
                split_arr.append(split_cache)
                #reset split cache
                split_cache = []
            else:
                #add character into split cache
                split_cache.append(ch)
        else:
            #add character into split cache
            split_cache.append(ch)
    #add remaining characters in output list
    split_arr.append(split_cache)
    return split_arr
