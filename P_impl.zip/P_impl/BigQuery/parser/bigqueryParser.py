# Generated from bigquery.g4 by ANTLR 4.7.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\u0094")
        buf.write("\u02a3\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31")
        buf.write("\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36")
        buf.write("\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t")
        buf.write("&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4,\t,\4-\t-\4.\t.\4")
        buf.write("/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\3\2\5\2h")
        buf.write("\n\2\3\2\3\2\3\2\3\3\3\3\3\3\5\3p\n\3\3\3\5\3s\n\3\3\3")
        buf.write("\3\3\3\3\3\3\5\3y\n\3\3\3\5\3|\n\3\5\3~\n\3\3\3\3\3\3")
        buf.write("\3\3\3\5\3\u0084\n\3\3\3\5\3\u0087\n\3\7\3\u0089\n\3\f")
        buf.write("\3\16\3\u008c\13\3\3\4\3\4\5\4\u0090\n\4\3\4\5\4\u0093")
        buf.write("\n\4\3\4\5\4\u0096\n\4\3\4\3\4\5\4\u009a\n\4\3\4\5\4\u009d")
        buf.write("\n\4\3\4\3\4\5\4\u00a1\n\4\3\4\5\4\u00a4\n\4\5\4\u00a6")
        buf.write("\n\4\3\4\3\4\5\4\u00aa\n\4\3\4\3\4\5\4\u00ae\n\4\3\4\5")
        buf.write("\4\u00b1\n\4\3\4\3\4\5\4\u00b5\n\4\3\4\5\4\u00b8\n\4\5")
        buf.write("\4\u00ba\n\4\7\4\u00bc\n\4\f\4\16\4\u00bf\13\4\3\4\5\4")
        buf.write("\u00c2\n\4\3\4\5\4\u00c5\n\4\3\4\5\4\u00c8\n\4\3\4\5\4")
        buf.write("\u00cb\n\4\3\5\3\5\3\5\3\5\7\5\u00d1\n\5\f\5\16\5\u00d4")
        buf.write("\13\5\3\6\3\6\3\6\5\6\u00d9\n\6\3\6\5\6\u00dc\n\6\3\6")
        buf.write("\3\6\3\6\3\6\3\6\3\6\5\6\u00e4\n\6\3\6\3\6\3\6\3\6\5\6")
        buf.write("\u00ea\n\6\3\6\5\6\u00ed\n\6\5\6\u00ef\n\6\3\6\3\6\5\6")
        buf.write("\u00f3\n\6\3\6\3\6\3\6\3\6\5\6\u00f9\n\6\7\6\u00fb\n\6")
        buf.write("\f\6\16\6\u00fe\13\6\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\7")
        buf.write("\b\u0108\n\b\f\b\16\b\u010b\13\b\3\b\3\b\3\b\3\b\3\b\7")
        buf.write("\b\u0112\n\b\f\b\16\b\u0115\13\b\3\b\3\b\5\b\u0119\n\b")
        buf.write("\3\t\3\t\3\t\3\n\3\n\3\n\3\n\5\n\u0122\n\n\3\n\3\n\3\n")
        buf.write("\5\n\u0127\n\n\7\n\u0129\n\n\f\n\16\n\u012c\13\n\3\13")
        buf.write("\3\13\3\13\3\13\5\13\u0132\n\13\3\f\3\f\3\r\3\r\3\r\3")
        buf.write("\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\7\r\u0144\n")
        buf.write("\r\f\r\16\r\u0147\13\r\3\r\5\r\u014a\n\r\3\r\3\r\3\r\3")
        buf.write("\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u0157\n\r\3\r\3\r\3")
        buf.write("\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r")
        buf.write("\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u0174")
        buf.write("\n\r\3\r\3\r\5\r\u0178\n\r\3\r\3\r\3\r\3\r\3\r\5\r\u017f")
        buf.write("\n\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u018b")
        buf.write("\n\r\3\r\3\r\3\r\5\r\u0190\n\r\3\r\3\r\3\r\3\r\3\r\7\r")
        buf.write("\u0197\n\r\f\r\16\r\u019a\13\r\3\r\3\r\7\r\u019e\n\r\f")
        buf.write("\r\16\r\u01a1\13\r\3\16\3\16\3\16\6\16\u01a6\n\16\r\16")
        buf.write("\16\16\u01a7\3\16\3\16\5\16\u01ac\n\16\3\16\3\16\3\16")
        buf.write("\3\16\6\16\u01b2\n\16\r\16\16\16\u01b3\3\16\3\16\5\16")
        buf.write("\u01b8\n\16\3\16\3\16\5\16\u01bc\n\16\3\17\3\17\3\17\3")
        buf.write("\17\3\17\3\20\3\20\3\20\3\20\3\20\3\21\3\21\3\21\3\21")
        buf.write("\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\23\3\23\3\23\3\23")
        buf.write("\3\23\3\23\3\23\5\23\u01da\n\23\3\23\3\23\3\23\5\23\u01df")
        buf.write("\n\23\3\23\3\23\3\23\5\23\u01e4\n\23\3\23\5\23\u01e7\n")
        buf.write("\23\3\24\3\24\3\24\3\24\3\24\7\24\u01ee\n\24\f\24\16\24")
        buf.write("\u01f1\13\24\3\24\3\24\3\25\3\25\3\25\3\25\5\25\u01f9")
        buf.write("\n\25\3\25\5\25\u01fc\n\25\3\25\3\25\3\25\5\25\u0201\n")
        buf.write("\25\3\25\7\25\u0204\n\25\f\25\16\25\u0207\13\25\3\25\3")
        buf.write("\25\3\26\3\26\3\26\3\26\5\26\u020f\n\26\3\26\3\26\5\26")
        buf.write("\u0213\n\26\3\26\3\26\5\26\u0217\n\26\5\26\u0219\n\26")
        buf.write("\3\27\3\27\3\27\3\30\3\30\5\30\u0220\n\30\3\30\3\30\3")
        buf.write("\30\3\30\5\30\u0226\n\30\3\31\3\31\3\31\3\31\3\31\7\31")
        buf.write("\u022d\n\31\f\31\16\31\u0230\13\31\3\31\3\31\3\32\3\32")
        buf.write("\3\33\3\33\3\34\3\34\3\35\3\35\3\35\3\35\3\35\3\35\3\35")
        buf.write("\3\35\3\35\3\35\3\35\3\35\3\35\7\35\u0247\n\35\f\35\16")
        buf.write("\35\u024a\13\35\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36")
        buf.write("\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36\5\36\u025d")
        buf.write("\n\36\3\37\3\37\3 \3 \3!\3!\3\"\3\"\3#\3#\3$\3$\5$\u026b")
        buf.write("\n$\3%\3%\3&\3&\3\'\3\'\3(\3(\3(\5(\u0276\n(\3(\3(\3(")
        buf.write("\5(\u027b\n(\3(\3(\3(\3(\3(\5(\u0282\n(\3)\3)\5)\u0286")
        buf.write("\n)\3*\3*\3+\3+\3,\3,\3,\3,\3,\3,\5,\u0292\n,\3-\3-\3")
        buf.write(".\3.\3/\3/\3\60\3\60\3\61\3\61\3\62\3\62\3\62\3\63\3\63")
        buf.write("\3\63\2\5\4\n\30\64\2\4\6\b\n\f\16\20\22\24\26\30\32\34")
        buf.write("\36 \"$&(*,.\60\62\64\668:<>@BDFHJLNPRTVXZ\\^`bd\2\r\4")
        buf.write("\2  \65\65\4\2%%\64\64\4\2\t\n[[\4\2\b\bBB\4\2\7\7\13")
        buf.write("\13\4\2\t\t\f\f\3\2\r\16\5\2>>\\\\||\3\2\u0086\u008a\4")
        buf.write("\2\6\6\32\32\3\2 \u008a\2\u02eb\2g\3\2\2\2\4}\3\2\2\2")
        buf.write("\6\u008d\3\2\2\2\b\u00cc\3\2\2\2\n\u00ee\3\2\2\2\f\u00ff")
        buf.write("\3\2\2\2\16\u0102\3\2\2\2\20\u011a\3\2\2\2\22\u011d\3")
        buf.write("\2\2\2\24\u012d\3\2\2\2\26\u0133\3\2\2\2\30\u0156\3\2")
        buf.write("\2\2\32\u01bb\3\2\2\2\34\u01bd\3\2\2\2\36\u01c2\3\2\2")
        buf.write("\2 \u01c7\3\2\2\2\"\u01cb\3\2\2\2$\u01e6\3\2\2\2&\u01e8")
        buf.write("\3\2\2\2(\u01f4\3\2\2\2*\u0218\3\2\2\2,\u021a\3\2\2\2")
        buf.write(".\u0225\3\2\2\2\60\u0227\3\2\2\2\62\u0233\3\2\2\2\64\u0235")
        buf.write("\3\2\2\2\66\u0237\3\2\2\28\u0239\3\2\2\2:\u025c\3\2\2")
        buf.write("\2<\u025e\3\2\2\2>\u0260\3\2\2\2@\u0262\3\2\2\2B\u0264")
        buf.write("\3\2\2\2D\u0266\3\2\2\2F\u026a\3\2\2\2H\u026c\3\2\2\2")
        buf.write("J\u026e\3\2\2\2L\u0270\3\2\2\2N\u0281\3\2\2\2P\u0285\3")
        buf.write("\2\2\2R\u0287\3\2\2\2T\u0289\3\2\2\2V\u0291\3\2\2\2X\u0293")
        buf.write("\3\2\2\2Z\u0295\3\2\2\2\\\u0297\3\2\2\2^\u0299\3\2\2\2")
        buf.write("`\u029b\3\2\2\2b\u029d\3\2\2\2d\u02a0\3\2\2\2fh\58\35")
        buf.write("\2gf\3\2\2\2gh\3\2\2\2hi\3\2\2\2ij\5\4\3\2jk\7\3\2\2k")
        buf.write("\3\3\2\2\2lm\b\3\1\2mo\5\6\4\2np\5\22\n\2on\3\2\2\2op")
        buf.write("\3\2\2\2pr\3\2\2\2qs\5\24\13\2rq\3\2\2\2rs\3\2\2\2s~\3")
        buf.write("\2\2\2tu\7\4\2\2uv\5\4\3\2vx\7\5\2\2wy\5\22\n\2xw\3\2")
        buf.write("\2\2xy\3\2\2\2y{\3\2\2\2z|\5\24\13\2{z\3\2\2\2{|\3\2\2")
        buf.write("\2|~\3\2\2\2}l\3\2\2\2}t\3\2\2\2~\u008a\3\2\2\2\177\u0080")
        buf.write("\f\3\2\2\u0080\u0081\5.\30\2\u0081\u0083\5\4\3\2\u0082")
        buf.write("\u0084\5\22\n\2\u0083\u0082\3\2\2\2\u0083\u0084\3\2\2")
        buf.write("\2\u0084\u0086\3\2\2\2\u0085\u0087\5\24\13\2\u0086\u0085")
        buf.write("\3\2\2\2\u0086\u0087\3\2\2\2\u0087\u0089\3\2\2\2\u0088")
        buf.write("\177\3\2\2\2\u0089\u008c\3\2\2\2\u008a\u0088\3\2\2\2\u008a")
        buf.write("\u008b\3\2\2\2\u008b\5\3\2\2\2\u008c\u008a\3\2\2\2\u008d")
        buf.write("\u008f\7r\2\2\u008e\u0090\t\2\2\2\u008f\u008e\3\2\2\2")
        buf.write("\u008f\u0090\3\2\2\2\u0090\u00a5\3\2\2\2\u0091\u0093\5")
        buf.write("\30\r\2\u0092\u0091\3\2\2\2\u0092\u0093\3\2\2\2\u0093")
        buf.write("\u0095\3\2\2\2\u0094\u0096\7\6\2\2\u0095\u0094\3\2\2\2")
        buf.write("\u0095\u0096\3\2\2\2\u0096\u0097\3\2\2\2\u0097\u0099\7")
        buf.write("\7\2\2\u0098\u009a\5&\24\2\u0099\u0098\3\2\2\2\u0099\u009a")
        buf.write("\3\2\2\2\u009a\u009c\3\2\2\2\u009b\u009d\5(\25\2\u009c")
        buf.write("\u009b\3\2\2\2\u009c\u009d\3\2\2\2\u009d\u00a6\3\2\2\2")
        buf.write("\u009e\u00a3\5\30\r\2\u009f\u00a1\7$\2\2\u00a0\u009f\3")
        buf.write("\2\2\2\u00a0\u00a1\3\2\2\2\u00a1\u00a2\3\2\2\2\u00a2\u00a4")
        buf.write("\5<\37\2\u00a3\u00a0\3\2\2\2\u00a3\u00a4\3\2\2\2\u00a4")
        buf.write("\u00a6\3\2\2\2\u00a5\u0092\3\2\2\2\u00a5\u009e\3\2\2\2")
        buf.write("\u00a6\u00bd\3\2\2\2\u00a7\u00b9\7\b\2\2\u00a8\u00aa\5")
        buf.write("\30\r\2\u00a9\u00a8\3\2\2\2\u00a9\u00aa\3\2\2\2\u00aa")
        buf.write("\u00ab\3\2\2\2\u00ab\u00ad\7\7\2\2\u00ac\u00ae\5&\24\2")
        buf.write("\u00ad\u00ac\3\2\2\2\u00ad\u00ae\3\2\2\2\u00ae\u00b0\3")
        buf.write("\2\2\2\u00af\u00b1\5(\25\2\u00b0\u00af\3\2\2\2\u00b0\u00b1")
        buf.write("\3\2\2\2\u00b1\u00ba\3\2\2\2\u00b2\u00b7\5\30\r\2\u00b3")
        buf.write("\u00b5\7$\2\2\u00b4\u00b3\3\2\2\2\u00b4\u00b5\3\2\2\2")
        buf.write("\u00b5\u00b6\3\2\2\2\u00b6\u00b8\5<\37\2\u00b7\u00b4\3")
        buf.write("\2\2\2\u00b7\u00b8\3\2\2\2\u00b8\u00ba\3\2\2\2\u00b9\u00a9")
        buf.write("\3\2\2\2\u00b9\u00b2\3\2\2\2\u00ba\u00bc\3\2\2\2\u00bb")
        buf.write("\u00a7\3\2\2\2\u00bc\u00bf\3\2\2\2\u00bd\u00bb\3\2\2\2")
        buf.write("\u00bd\u00be\3\2\2\2\u00be\u00c1\3\2\2\2\u00bf\u00bd\3")
        buf.write("\2\2\2\u00c0\u00c2\5\b\5\2\u00c1\u00c0\3\2\2\2\u00c1\u00c2")
        buf.write("\3\2\2\2\u00c2\u00c4\3\2\2\2\u00c3\u00c5\5\f\7\2\u00c4")
        buf.write("\u00c3\3\2\2\2\u00c4\u00c5\3\2\2\2\u00c5\u00c7\3\2\2\2")
        buf.write("\u00c6\u00c8\5\16\b\2\u00c7\u00c6\3\2\2\2\u00c7\u00c8")
        buf.write("\3\2\2\2\u00c8\u00ca\3\2\2\2\u00c9\u00cb\5\20\t\2\u00ca")
        buf.write("\u00c9\3\2\2\2\u00ca\u00cb\3\2\2\2\u00cb\7\3\2\2\2\u00cc")
        buf.write("\u00cd\7B\2\2\u00cd\u00d2\5\n\6\2\u00ce\u00cf\7\b\2\2")
        buf.write("\u00cf\u00d1\5\n\6\2\u00d0\u00ce\3\2\2\2\u00d1\u00d4\3")
        buf.write("\2\2\2\u00d2\u00d0\3\2\2\2\u00d2\u00d3\3\2\2\2\u00d3\t")
        buf.write("\3\2\2\2\u00d4\u00d2\3\2\2\2\u00d5\u00d6\b\6\1\2\u00d6")
        buf.write("\u00db\5N(\2\u00d7\u00d9\7$\2\2\u00d8\u00d7\3\2\2\2\u00d8")
        buf.write("\u00d9\3\2\2\2\u00d9\u00da\3\2\2\2\u00da\u00dc\5<\37\2")
        buf.write("\u00db\u00d8\3\2\2\2\u00db\u00dc\3\2\2\2\u00dc\u00e3\3")
        buf.write("\2\2\2\u00dd\u00de\7A\2\2\u00de\u00df\7v\2\2\u00df\u00e0")
        buf.write("\7y\2\2\u00e0\u00e1\7$\2\2\u00e1\u00e2\7^\2\2\u00e2\u00e4")
        buf.write("\5V,\2\u00e3\u00dd\3\2\2\2\u00e3\u00e4\3\2\2\2\u00e4\u00ef")
        buf.write("\3\2\2\2\u00e5\u00e6\7\4\2\2\u00e6\u00e7\5\2\2\2\u00e7")
        buf.write("\u00ec\7\5\2\2\u00e8\u00ea\7$\2\2\u00e9\u00e8\3\2\2\2")
        buf.write("\u00e9\u00ea\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00ed\5")
        buf.write("<\37\2\u00ec\u00e9\3\2\2\2\u00ec\u00ed\3\2\2\2\u00ed\u00ef")
        buf.write("\3\2\2\2\u00ee\u00d5\3\2\2\2\u00ee\u00e5\3\2\2\2\u00ef")
        buf.write("\u00fc\3\2\2\2\u00f0\u00f2\f\4\2\2\u00f1\u00f3\5*\26\2")
        buf.write("\u00f2\u00f1\3\2\2\2\u00f2\u00f3\3\2\2\2\u00f3\u00f4\3")
        buf.write("\2\2\2\u00f4\u00f5\7Q\2\2\u00f5\u00f8\5\n\6\2\u00f6\u00f9")
        buf.write("\5,\27\2\u00f7\u00f9\5\60\31\2\u00f8\u00f6\3\2\2\2\u00f8")
        buf.write("\u00f7\3\2\2\2\u00f9\u00fb\3\2\2\2\u00fa\u00f0\3\2\2\2")
        buf.write("\u00fb\u00fe\3\2\2\2\u00fc\u00fa\3\2\2\2\u00fc\u00fd\3")
        buf.write("\2\2\2\u00fd\13\3\2\2\2\u00fe\u00fc\3\2\2\2\u00ff\u0100")
        buf.write("\7\u0082\2\2\u0100\u0101\5\62\32\2\u0101\r\3\2\2\2\u0102")
        buf.write("\u0103\7D\2\2\u0103\u0118\7)\2\2\u0104\u0109\5\30\r\2")
        buf.write("\u0105\u0106\7\b\2\2\u0106\u0108\5\30\r\2\u0107\u0105")
        buf.write("\3\2\2\2\u0108\u010b\3\2\2\2\u0109\u0107\3\2\2\2\u0109")
        buf.write("\u010a\3\2\2\2\u010a\u0119\3\2\2\2\u010b\u0109\3\2\2\2")
        buf.write("\u010c\u010d\7n\2\2\u010d\u010e\7\4\2\2\u010e\u0113\5")
        buf.write("\30\r\2\u010f\u0110\7\b\2\2\u0110\u0112\5\30\r\2\u0111")
        buf.write("\u010f\3\2\2\2\u0112\u0115\3\2\2\2\u0113\u0111\3\2\2\2")
        buf.write("\u0113\u0114\3\2\2\2\u0114\u0116\3\2\2\2\u0115\u0113\3")
        buf.write("\2\2\2\u0116\u0117\7\5\2\2\u0117\u0119\3\2\2\2\u0118\u0104")
        buf.write("\3\2\2\2\u0118\u010c\3\2\2\2\u0119\17\3\2\2\2\u011a\u011b")
        buf.write("\7H\2\2\u011b\u011c\5\62\32\2\u011c\21\3\2\2\2\u011d\u011e")
        buf.write("\7b\2\2\u011e\u011f\7)\2\2\u011f\u0121\5\30\r\2\u0120")
        buf.write("\u0122\t\3\2\2\u0121\u0120\3\2\2\2\u0121\u0122\3\2\2\2")
        buf.write("\u0122\u012a\3\2\2\2\u0123\u0124\7\b\2\2\u0124\u0126\5")
        buf.write("\30\r\2\u0125\u0127\t\3\2\2\u0126\u0125\3\2\2\2\u0126")
        buf.write("\u0127\3\2\2\2\u0127\u0129\3\2\2\2\u0128\u0123\3\2\2\2")
        buf.write("\u0129\u012c\3\2\2\2\u012a\u0128\3\2\2\2\u012a\u012b\3")
        buf.write("\2\2\2\u012b\23\3\2\2\2\u012c\u012a\3\2\2\2\u012d\u012e")
        buf.write("\7U\2\2\u012e\u0131\5\64\33\2\u012f\u0130\7_\2\2\u0130")
        buf.write("\u0132\5\66\34\2\u0131\u012f\3\2\2\2\u0131\u0132\3\2\2")
        buf.write("\2\u0132\25\3\2\2\2\u0133\u0134\t\4\2\2\u0134\27\3\2\2")
        buf.write("\2\u0135\u0136\b\r\1\2\u0136\u0157\5P)\2\u0137\u0157\5")
        buf.write("V,\2\u0138\u0157\5\6\4\2\u0139\u013a\5\26\f\2\u013a\u013b")
        buf.write("\5\30\r\26\u013b\u0157\3\2\2\2\u013c\u013d\7*\2\2\u013d")
        buf.write("\u0157\5\30\r\2\u013e\u013f\5F$\2\u013f\u0149\7\4\2\2")
        buf.write("\u0140\u0145\5\30\r\2\u0141\u0142\t\5\2\2\u0142\u0144")
        buf.write("\5\30\r\2\u0143\u0141\3\2\2\2\u0144\u0147\3\2\2\2\u0145")
        buf.write("\u0143\3\2\2\2\u0145\u0146\3\2\2\2\u0146\u014a\3\2\2\2")
        buf.write("\u0147\u0145\3\2\2\2\u0148\u014a\7\7\2\2\u0149\u0140\3")
        buf.write("\2\2\2\u0149\u0148\3\2\2\2\u0149\u014a\3\2\2\2\u014a\u014b")
        buf.write("\3\2\2\2\u014b\u014c\7\5\2\2\u014c\u0157\3\2\2\2\u014d")
        buf.write("\u0157\5\"\22\2\u014e\u0157\5\32\16\2\u014f\u0157\5 \21")
        buf.write("\2\u0150\u0151\7\4\2\2\u0151\u0152\5\30\r\2\u0152\u0153")
        buf.write("\7\5\2\2\u0153\u0157\3\2\2\2\u0154\u0157\5$\23\2\u0155")
        buf.write("\u0157\5d\63\2\u0156\u0135\3\2\2\2\u0156\u0137\3\2\2\2")
        buf.write("\u0156\u0138\3\2\2\2\u0156\u0139\3\2\2\2\u0156\u013c\3")
        buf.write("\2\2\2\u0156\u013e\3\2\2\2\u0156\u014d\3\2\2\2\u0156\u014e")
        buf.write("\3\2\2\2\u0156\u014f\3\2\2\2\u0156\u0150\3\2\2\2\u0156")
        buf.write("\u0154\3\2\2\2\u0156\u0155\3\2\2\2\u0157\u019f\3\2\2\2")
        buf.write("\u0158\u0159\f\25\2\2\u0159\u015a\t\6\2\2\u015a\u019e")
        buf.write("\5\30\r\26\u015b\u015c\f\24\2\2\u015c\u015d\t\7\2\2\u015d")
        buf.write("\u019e\5\30\r\25\u015e\u015f\f\23\2\2\u015f\u0160\t\b")
        buf.write("\2\2\u0160\u019e\5\30\r\24\u0161\u0162\f\22\2\2\u0162")
        buf.write("\u0163\7\17\2\2\u0163\u019e\5\30\r\23\u0164\u0165\f\21")
        buf.write("\2\2\u0165\u0166\7\20\2\2\u0166\u019e\5\30\r\22\u0167")
        buf.write("\u0168\f\20\2\2\u0168\u0169\7\21\2\2\u0169\u019e\5\30")
        buf.write("\r\21\u016a\u017e\f\16\2\2\u016b\u017f\7\22\2\2\u016c")
        buf.write("\u017f\7\23\2\2\u016d\u017f\7\24\2\2\u016e\u017f\7\25")
        buf.write("\2\2\u016f\u017f\7\26\2\2\u0170\u017f\7\27\2\2\u0171\u017f")
        buf.write("\7\30\2\2\u0172\u0174\7[\2\2\u0173\u0172\3\2\2\2\u0173")
        buf.write("\u0174\3\2\2\2\u0174\u0175\3\2\2\2\u0175\u017f\7T\2\2")
        buf.write("\u0176\u0178\7[\2\2\u0177\u0176\3\2\2\2\u0177\u0178\3")
        buf.write("\2\2\2\u0178\u0179\3\2\2\2\u0179\u017a\7(\2\2\u017a\u017b")
        buf.write("\5\30\r\2\u017b\u017c\7!\2\2\u017c\u017d\5\30\r\2\u017d")
        buf.write("\u017f\3\2\2\2\u017e\u016b\3\2\2\2\u017e\u016c\3\2\2\2")
        buf.write("\u017e\u016d\3\2\2\2\u017e\u016e\3\2\2\2\u017e\u016f\3")
        buf.write("\2\2\2\u017e\u0170\3\2\2\2\u017e\u0171\3\2\2\2\u017e\u0173")
        buf.write("\3\2\2\2\u017e\u0177\3\2\2\2\u017f\u0180\3\2\2\2\u0180")
        buf.write("\u019e\5\30\r\17\u0181\u0182\f\13\2\2\u0182\u0183\7!\2")
        buf.write("\2\u0183\u019e\5\30\r\f\u0184\u0185\f\n\2\2\u0185\u0186")
        buf.write("\7a\2\2\u0186\u019e\5\30\r\13\u0187\u0188\f\r\2\2\u0188")
        buf.write("\u018a\7P\2\2\u0189\u018b\7[\2\2\u018a\u0189\3\2\2\2\u018a")
        buf.write("\u018b\3\2\2\2\u018b\u018c\3\2\2\2\u018c\u019e\t\t\2\2")
        buf.write("\u018d\u018f\f\f\2\2\u018e\u0190\7[\2\2\u018f\u018e\3")
        buf.write("\2\2\2\u018f\u0190\3\2\2\2\u0190\u0191\3\2\2\2\u0191\u0192")
        buf.write("\7K\2\2\u0192\u0193\7\4\2\2\u0193\u0198\5\30\r\2\u0194")
        buf.write("\u0195\7\b\2\2\u0195\u0197\5\30\r\2\u0196\u0194\3\2\2")
        buf.write("\2\u0197\u019a\3\2\2\2\u0198\u0196\3\2\2\2\u0198\u0199")
        buf.write("\3\2\2\2\u0199\u019b\3\2\2\2\u019a\u0198\3\2\2\2\u019b")
        buf.write("\u019c\7\5\2\2\u019c\u019e\3\2\2\2\u019d\u0158\3\2\2\2")
        buf.write("\u019d\u015b\3\2\2\2\u019d\u015e\3\2\2\2\u019d\u0161\3")
        buf.write("\2\2\2\u019d\u0164\3\2\2\2\u019d\u0167\3\2\2\2\u019d\u016a")
        buf.write("\3\2\2\2\u019d\u0181\3\2\2\2\u019d\u0184\3\2\2\2\u019d")
        buf.write("\u0187\3\2\2\2\u019d\u018d\3\2\2\2\u019e\u01a1\3\2\2\2")
        buf.write("\u019f\u019d\3\2\2\2\u019f\u01a0\3\2\2\2\u01a0\31\3\2")
        buf.write("\2\2\u01a1\u019f\3\2\2\2\u01a2\u01a3\7*\2\2\u01a3\u01a5")
        buf.write("\5\30\r\2\u01a4\u01a6\5\34\17\2\u01a5\u01a4\3\2\2\2\u01a6")
        buf.write("\u01a7\3\2\2\2\u01a7\u01a5\3\2\2\2\u01a7\u01a8\3\2\2\2")
        buf.write("\u01a8\u01ab\3\2\2\2\u01a9\u01aa\7\66\2\2\u01aa\u01ac")
        buf.write("\5\30\r\2\u01ab\u01a9\3\2\2\2\u01ab\u01ac\3\2\2\2\u01ac")
        buf.write("\u01ad\3\2\2\2\u01ad\u01ae\7\67\2\2\u01ae\u01bc\3\2\2")
        buf.write("\2\u01af\u01b1\7*\2\2\u01b0\u01b2\5\36\20\2\u01b1\u01b0")
        buf.write("\3\2\2\2\u01b2\u01b3\3\2\2\2\u01b3\u01b1\3\2\2\2\u01b3")
        buf.write("\u01b4\3\2\2\2\u01b4\u01b7\3\2\2\2\u01b5\u01b6\7\66\2")
        buf.write("\2\u01b6\u01b8\5\30\r\2\u01b7\u01b5\3\2\2\2\u01b7\u01b8")
        buf.write("\3\2\2\2\u01b8\u01b9\3\2\2\2\u01b9\u01ba\7\67\2\2\u01ba")
        buf.write("\u01bc\3\2\2\2\u01bb\u01a2\3\2\2\2\u01bb\u01af\3\2\2\2")
        buf.write("\u01bc\33\3\2\2\2\u01bd\u01be\7\u0081\2\2\u01be\u01bf")
        buf.write("\5\30\r\2\u01bf\u01c0\7x\2\2\u01c0\u01c1\5\30\r\2\u01c1")
        buf.write("\35\3\2\2\2\u01c2\u01c3\7\u0081\2\2\u01c3\u01c4\5\62\32")
        buf.write("\2\u01c4\u01c5\7x\2\2\u01c5\u01c6\5\30\r\2\u01c6\37\3")
        buf.write("\2\2\2\u01c7\u01c8\7N\2\2\u01c8\u01c9\5R*\2\u01c9\u01ca")
        buf.write("\t\n\2\2\u01ca!\3\2\2\2\u01cb\u01cc\7+\2\2\u01cc\u01cd")
        buf.write("\7\4\2\2\u01cd\u01ce\5\30\r\2\u01ce\u01cf\7$\2\2\u01cf")
        buf.write("\u01d0\5D#\2\u01d0\u01d1\7\5\2\2\u01d1#\3\2\2\2\u01d2")
        buf.write("\u01d3\7\31\2\2\u01d3\u01d4\5$\23\2\u01d4\u01d5\7\31\2")
        buf.write("\2\u01d5\u01e7\3\2\2\2\u01d6\u01d7\5J&\2\u01d7\u01d8\7")
        buf.write("\6\2\2\u01d8\u01da\3\2\2\2\u01d9\u01d6\3\2\2\2\u01d9\u01da")
        buf.write("\3\2\2\2\u01da\u01db\3\2\2\2\u01db\u01dc\5B\"\2\u01dc")
        buf.write("\u01dd\7\6\2\2\u01dd\u01df\3\2\2\2\u01de\u01d9\3\2\2\2")
        buf.write("\u01de\u01df\3\2\2\2\u01df\u01e0\3\2\2\2\u01e0\u01e1\5")
        buf.write("L\'\2\u01e1\u01e2\7\6\2\2\u01e2\u01e4\3\2\2\2\u01e3\u01de")
        buf.write("\3\2\2\2\u01e3\u01e4\3\2\2\2\u01e4\u01e5\3\2\2\2\u01e5")
        buf.write("\u01e7\5> \2\u01e6\u01d2\3\2\2\2\u01e6\u01e3\3\2\2\2\u01e7")
        buf.write("%\3\2\2\2\u01e8\u01e9\7:\2\2\u01e9\u01ea\7\4\2\2\u01ea")
        buf.write("\u01ef\5> \2\u01eb\u01ec\7\b\2\2\u01ec\u01ee\5> \2\u01ed")
        buf.write("\u01eb\3\2\2\2\u01ee\u01f1\3\2\2\2\u01ef\u01ed\3\2\2\2")
        buf.write("\u01ef\u01f0\3\2\2\2\u01f0\u01f2\3\2\2\2\u01f1\u01ef\3")
        buf.write("\2\2\2\u01f2\u01f3\7\5\2\2\u01f3\'\3\2\2\2\u01f4\u01f5")
        buf.write("\7k\2\2\u01f5\u01f6\7\4\2\2\u01f6\u01fb\5\30\r\2\u01f7")
        buf.write("\u01f9\7$\2\2\u01f8\u01f7\3\2\2\2\u01f8\u01f9\3\2\2\2")
        buf.write("\u01f9\u01fa\3\2\2\2\u01fa\u01fc\5<\37\2\u01fb\u01f8\3")
        buf.write("\2\2\2\u01fb\u01fc\3\2\2\2\u01fc\u01fd\3\2\2\2\u01fd\u01fe")
        buf.write("\7\b\2\2\u01fe\u0205\5\30\r\2\u01ff\u0201\7$\2\2\u0200")
        buf.write("\u01ff\3\2\2\2\u0200\u0201\3\2\2\2\u0201\u0202\3\2\2\2")
        buf.write("\u0202\u0204\5<\37\2\u0203\u0200\3\2\2\2\u0204\u0207\3")
        buf.write("\2\2\2\u0205\u0203\3\2\2\2\u0205\u0206\3\2\2\2\u0206\u0208")
        buf.write("\3\2\2\2\u0207\u0205\3\2\2\2\u0208\u0209\7\5\2\2\u0209")
        buf.write(")\3\2\2\2\u020a\u0219\7L\2\2\u020b\u0219\7/\2\2\u020c")
        buf.write("\u020e\7C\2\2\u020d\u020f\7d\2\2\u020e\u020d\3\2\2\2\u020e")
        buf.write("\u020f\3\2\2\2\u020f\u0219\3\2\2\2\u0210\u0212\7S\2\2")
        buf.write("\u0211\u0213\7d\2\2\u0212\u0211\3\2\2\2\u0212\u0213\3")
        buf.write("\2\2\2\u0213\u0219\3\2\2\2\u0214\u0216\7m\2\2\u0215\u0217")
        buf.write("\7d\2\2\u0216\u0215\3\2\2\2\u0216\u0217\3\2\2\2\u0217")
        buf.write("\u0219\3\2\2\2\u0218\u020a\3\2\2\2\u0218\u020b\3\2\2\2")
        buf.write("\u0218\u020c\3\2\2\2\u0218\u0210\3\2\2\2\u0218\u0214\3")
        buf.write("\2\2\2\u0219+\3\2\2\2\u021a\u021b\7`\2\2\u021b\u021c\5")
        buf.write("\62\32\2\u021c-\3\2\2\2\u021d\u021f\7~\2\2\u021e\u0220")
        buf.write("\t\2\2\2\u021f\u021e\3\2\2\2\u021f\u0220\3\2\2\2\u0220")
        buf.write("\u0226\3\2\2\2\u0221\u0222\7M\2\2\u0222\u0226\7\65\2\2")
        buf.write("\u0223\u0224\7:\2\2\u0224\u0226\7\65\2\2\u0225\u021d\3")
        buf.write("\2\2\2\u0225\u0221\3\2\2\2\u0225\u0223\3\2\2\2\u0226/")
        buf.write("\3\2\2\2\u0227\u0228\7\u0080\2\2\u0228\u0229\7\4\2\2\u0229")
        buf.write("\u022e\5H%\2\u022a\u022b\7\b\2\2\u022b\u022d\5H%\2\u022c")
        buf.write("\u022a\3\2\2\2\u022d\u0230\3\2\2\2\u022e\u022c\3\2\2\2")
        buf.write("\u022e\u022f\3\2\2\2\u022f\u0231\3\2\2\2\u0230\u022e\3")
        buf.write("\2\2\2\u0231\u0232\7\5\2\2\u0232\61\3\2\2\2\u0233\u0234")
        buf.write("\5\30\r\2\u0234\63\3\2\2\2\u0235\u0236\5P)\2\u0236\65")
        buf.write("\3\2\2\2\u0237\u0238\5P)\2\u0238\67\3\2\2\2\u0239\u023a")
        buf.write("\7\u0084\2\2\u023a\u023b\5@!\2\u023b\u023c\7$\2\2\u023c")
        buf.write("\u023d\7\4\2\2\u023d\u023e\5\4\3\2\u023e\u0248\7\5\2\2")
        buf.write("\u023f\u0240\7\b\2\2\u0240\u0241\5@!\2\u0241\u0242\7$")
        buf.write("\2\2\u0242\u0243\7\4\2\2\u0243\u0244\5\4\3\2\u0244\u0245")
        buf.write("\7\5\2\2\u0245\u0247\3\2\2\2\u0246\u023f\3\2\2\2\u0247")
        buf.write("\u024a\3\2\2\2\u0248\u0246\3\2\2\2\u0248\u0249\3\2\2\2")
        buf.write("\u02499\3\2\2\2\u024a\u0248\3\2\2\2\u024b\u025d\7\u0093")
        buf.write("\2\2\u024c\u024d\7\37\2\2\u024d\u024e\5:\36\2\u024e\u024f")
        buf.write("\7\37\2\2\u024f\u025d\3\2\2\2\u0250\u0251\7\4\2\2\u0251")
        buf.write("\u0252\5:\36\2\u0252\u0253\7\5\2\2\u0253\u025d\3\2\2\2")
        buf.write("\u0254\u0255\7\31\2\2\u0255\u0256\5:\36\2\u0256\u0257")
        buf.write("\7\31\2\2\u0257\u025d\3\2\2\2\u0258\u0259\7\36\2\2\u0259")
        buf.write("\u025a\5:\36\2\u025a\u025b\7\36\2\2\u025b\u025d\3\2\2")
        buf.write("\2\u025c\u024b\3\2\2\2\u025c\u024c\3\2\2\2\u025c\u0250")
        buf.write("\3\2\2\2\u025c\u0254\3\2\2\2\u025c\u0258\3\2\2\2\u025d")
        buf.write(";\3\2\2\2\u025e\u025f\5:\36\2\u025f=\3\2\2\2\u0260\u0261")
        buf.write("\5:\36\2\u0261?\3\2\2\2\u0262\u0263\5:\36\2\u0263A\3\2")
        buf.write("\2\2\u0264\u0265\5:\36\2\u0265C\3\2\2\2\u0266\u0267\5")
        buf.write(":\36\2\u0267E\3\2\2\2\u0268\u026b\5d\63\2\u0269\u026b")
        buf.write("\5:\36\2\u026a\u0268\3\2\2\2\u026a\u0269\3\2\2\2\u026b")
        buf.write("G\3\2\2\2\u026c\u026d\5:\36\2\u026dI\3\2\2\2\u026e\u026f")
        buf.write("\5:\36\2\u026fK\3\2\2\2\u0270\u0271\5:\36\2\u0271M\3\2")
        buf.write("\2\2\u0272\u0273\5J&\2\u0273\u0274\t\13\2\2\u0274\u0276")
        buf.write("\3\2\2\2\u0275\u0272\3\2\2\2\u0275\u0276\3\2\2\2\u0276")
        buf.write("\u0277\3\2\2\2\u0277\u0278\5B\"\2\u0278\u0279\t\13\2\2")
        buf.write("\u0279\u027b\3\2\2\2\u027a\u0275\3\2\2\2\u027a\u027b\3")
        buf.write("\2\2\2\u027b\u027c\3\2\2\2\u027c\u0282\5L\'\2\u027d\u027e")
        buf.write("\7\31\2\2\u027e\u027f\5N(\2\u027f\u0280\7\31\2\2\u0280")
        buf.write("\u0282\3\2\2\2\u0281\u027a\3\2\2\2\u0281\u027d\3\2\2\2")
        buf.write("\u0282O\3\2\2\2\u0283\u0286\5R*\2\u0284\u0286\5T+\2\u0285")
        buf.write("\u0283\3\2\2\2\u0285\u0284\3\2\2\2\u0286Q\3\2\2\2\u0287")
        buf.write("\u0288\7\33\2\2\u0288S\3\2\2\2\u0289\u028a\7\34\2\2\u028a")
        buf.write("U\3\2\2\2\u028b\u0292\5X-\2\u028c\u0292\5Z.\2\u028d\u0292")
        buf.write("\5\\/\2\u028e\u0292\5^\60\2\u028f\u0292\5`\61\2\u0290")
        buf.write("\u0292\5b\62\2\u0291\u028b\3\2\2\2\u0291\u028c\3\2\2\2")
        buf.write("\u0291\u028d\3\2\2\2\u0291\u028e\3\2\2\2\u0291\u028f\3")
        buf.write("\2\2\2\u0291\u0290\3\2\2\2\u0292W\3\2\2\2\u0293\u0294")
        buf.write("\7\u008e\2\2\u0294Y\3\2\2\2\u0295\u0296\7\u008f\2\2\u0296")
        buf.write("[\3\2\2\2\u0297\u0298\7\u0090\2\2\u0298]\3\2\2\2\u0299")
        buf.write("\u029a\7\u0091\2\2\u029a_\3\2\2\2\u029b\u029c\7\u0092")
        buf.write("\2\2\u029ca\3\2\2\2\u029d\u029e\5D#\2\u029e\u029f\7\u008e")
        buf.write("\2\2\u029fc\3\2\2\2\u02a0\u02a1\t\f\2\2\u02a1e\3\2\2\2")
        buf.write("Wgorx{}\u0083\u0086\u008a\u008f\u0092\u0095\u0099\u009c")
        buf.write("\u00a0\u00a3\u00a5\u00a9\u00ad\u00b0\u00b4\u00b7\u00b9")
        buf.write("\u00bd\u00c1\u00c4\u00c7\u00ca\u00d2\u00d8\u00db\u00e3")
        buf.write("\u00e9\u00ec\u00ee\u00f2\u00f8\u00fc\u0109\u0113\u0118")
        buf.write("\u0121\u0126\u012a\u0131\u0145\u0149\u0156\u0173\u0177")
        buf.write("\u017e\u018a\u018f\u0198\u019d\u019f\u01a7\u01ab\u01b3")
        buf.write("\u01b7\u01bb\u01d9\u01de\u01e3\u01e6\u01ef\u01f8\u01fb")
        buf.write("\u0200\u0205\u020e\u0212\u0216\u0218\u021f\u0225\u022e")
        buf.write("\u0248\u025c\u026a\u0275\u027a\u0281\u0285\u0291")
        return buf.getvalue()


class bigqueryParser ( Parser ):

    grammarFileName = "bigquery.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'('", "')'", "'.'", "'*'", "','", 
                     "'-'", "'~'", "'/'", "'+'", "'<<'", "'>>'", "'&'", 
                     "'^'", "'|'", "'='", "'<'", "'>'", "'<='", "'>='", 
                     "'!='", "'<>'", "'`'", "':'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'''", "'\"'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "INT", "FLOAT", "DIGITS", "QUOTE", "DQOUTE", 
                      "ALL", "AND", "ANY", "ARRAY", "AS", "ASC", "ASSERT_ROWS_MODIFIED", 
                      "AT", "BETWEEN", "BY", "CASE", "CAST", "COLLATE", 
                      "CONTAINS", "CREATE", "CROSS", "CUBE", "CURRENT", 
                      "DEFAULT", "DEFINE", "DESC", "DISTINCT", "ELSE", "END", 
                      "ENUM", "ESCAPE", "EXCEPT", "EXCLUDE", "EXISTS", "EXTRACT", 
                      "FALSE", "FETCH", "FOLLOWING", "FOR", "FROM", "FULL", 
                      "GROUP", "GROUPING", "GROUPS", "HASH", "HAVING", "IF", 
                      "IGNORE", "IN", "INNER", "INTERSECT", "INTERVAL", 
                      "INTO", "IS", "JOIN", "LATERAL", "LEFT", "LIKE", "LIMIT", 
                      "LOOKUP", "MERGE", "NATURAL", "NEW", "NO", "NOT", 
                      "S_NULL", "NULLS", "OF", "OFFSET", "ON", "OR", "ORDER", 
                      "ORDINAL", "OUTER", "OVER", "PARTITION", "PRECEDING", 
                      "PROTO", "RANGE", "RECURSIVE", "REPLACE", "RESPECT", 
                      "RIGHT", "ROLLUP", "ROWS", "SAFE_OFFSET", "SAFE_ORDINAL", 
                      "SELECT", "SET", "SOME", "SSTRUCT", "SYSTEM", "TABLESAMPLE", 
                      "THEN", "TIME", "TO", "TREAT", "TRUE", "UNBOUNDED", 
                      "UNION", "UNNEST", "USING", "WHEN", "WHERE", "WINDOW", 
                      "WITH", "WITHIN", "DAY", "YEAR", "MONTH", "WEEK", 
                      "QUARTER", "WS", "CMT", "M_CMT", "QUOTED_STRING", 
                      "TRIPLE_QUOTED_STRING", "RAW_STRING", "BYTE_STRING", 
                      "RAW_BYTE_STRING", "ID", "RB" ]

    RULE_query_statement = 0
    RULE_query_expr = 1
    RULE_select_statement = 2
    RULE_from_statement = 3
    RULE_from_item = 4
    RULE_where_statement = 5
    RULE_group_statement = 6
    RULE_having_statement = 7
    RULE_order_clause = 8
    RULE_limit_clause = 9
    RULE_unary_operator = 10
    RULE_expr = 11
    RULE_case_expr = 12
    RULE_switch_section = 13
    RULE_switch_search_condition_section = 14
    RULE_interval_delta = 15
    RULE_cast_expr = 16
    RULE_column_expr = 17
    RULE_except_statement = 18
    RULE_replace_statement = 19
    RULE_join_type = 20
    RULE_on_clause = 21
    RULE_set_op = 22
    RULE_using_clause = 23
    RULE_bool_expression = 24
    RULE_count = 25
    RULE_skip_rows = 26
    RULE_with_statement = 27
    RULE_name = 28
    RULE_alias_name = 29
    RULE_column_name = 30
    RULE_cte_name = 31
    RULE_dataset_name = 32
    RULE_datatype_name = 33
    RULE_function_name = 34
    RULE_join_name = 35
    RULE_project_name = 36
    RULE_table_name = 37
    RULE_table_expr = 38
    RULE_number = 39
    RULE_integer_type = 40
    RULE_float_type = 41
    RULE_string = 42
    RULE_quoted_string = 43
    RULE_triple_quoted_string = 44
    RULE_raw_string = 45
    RULE_byte_string = 46
    RULE_raw_byte_string = 47
    RULE_special_string = 48
    RULE_keyword = 49

    ruleNames =  [ "query_statement", "query_expr", "select_statement", 
                   "from_statement", "from_item", "where_statement", "group_statement", 
                   "having_statement", "order_clause", "limit_clause", "unary_operator", 
                   "expr", "case_expr", "switch_section", "switch_search_condition_section", 
                   "interval_delta", "cast_expr", "column_expr", "except_statement", 
                   "replace_statement", "join_type", "on_clause", "set_op", 
                   "using_clause", "bool_expression", "count", "skip_rows", 
                   "with_statement", "name", "alias_name", "column_name", 
                   "cte_name", "dataset_name", "datatype_name", "function_name", 
                   "join_name", "project_name", "table_name", "table_expr", 
                   "number", "integer_type", "float_type", "string", "quoted_string", 
                   "triple_quoted_string", "raw_string", "byte_string", 
                   "raw_byte_string", "special_string", "keyword" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    INT=25
    FLOAT=26
    DIGITS=27
    QUOTE=28
    DQOUTE=29
    ALL=30
    AND=31
    ANY=32
    ARRAY=33
    AS=34
    ASC=35
    ASSERT_ROWS_MODIFIED=36
    AT=37
    BETWEEN=38
    BY=39
    CASE=40
    CAST=41
    COLLATE=42
    CONTAINS=43
    CREATE=44
    CROSS=45
    CUBE=46
    CURRENT=47
    DEFAULT=48
    DEFINE=49
    DESC=50
    DISTINCT=51
    ELSE=52
    END=53
    ENUM=54
    ESCAPE=55
    EXCEPT=56
    EXCLUDE=57
    EXISTS=58
    EXTRACT=59
    FALSE=60
    FETCH=61
    FOLLOWING=62
    FOR=63
    FROM=64
    FULL=65
    GROUP=66
    GROUPING=67
    GROUPS=68
    HASH=69
    HAVING=70
    IF=71
    IGNORE=72
    IN=73
    INNER=74
    INTERSECT=75
    INTERVAL=76
    INTO=77
    IS=78
    JOIN=79
    LATERAL=80
    LEFT=81
    LIKE=82
    LIMIT=83
    LOOKUP=84
    MERGE=85
    NATURAL=86
    NEW=87
    NO=88
    NOT=89
    S_NULL=90
    NULLS=91
    OF=92
    OFFSET=93
    ON=94
    OR=95
    ORDER=96
    ORDINAL=97
    OUTER=98
    OVER=99
    PARTITION=100
    PRECEDING=101
    PROTO=102
    RANGE=103
    RECURSIVE=104
    REPLACE=105
    RESPECT=106
    RIGHT=107
    ROLLUP=108
    ROWS=109
    SAFE_OFFSET=110
    SAFE_ORDINAL=111
    SELECT=112
    SET=113
    SOME=114
    SSTRUCT=115
    SYSTEM=116
    TABLESAMPLE=117
    THEN=118
    TIME=119
    TO=120
    TREAT=121
    TRUE=122
    UNBOUNDED=123
    UNION=124
    UNNEST=125
    USING=126
    WHEN=127
    WHERE=128
    WINDOW=129
    WITH=130
    WITHIN=131
    DAY=132
    YEAR=133
    MONTH=134
    WEEK=135
    QUARTER=136
    WS=137
    CMT=138
    M_CMT=139
    QUOTED_STRING=140
    TRIPLE_QUOTED_STRING=141
    RAW_STRING=142
    BYTE_STRING=143
    RAW_BYTE_STRING=144
    ID=145
    RB=146

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Query_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def query_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Query_exprContext,0)


        def with_statement(self):
            return self.getTypedRuleContext(bigqueryParser.With_statementContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_query_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuery_statement" ):
                listener.enterQuery_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuery_statement" ):
                listener.exitQuery_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuery_statement" ):
                return visitor.visitQuery_statement(self)
            else:
                return visitor.visitChildren(self)




    def query_statement(self):

        localctx = bigqueryParser.Query_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_query_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==bigqueryParser.WITH:
                self.state = 100
                self.with_statement()


            self.state = 103
            self.query_expr(0)
            self.state = 104
            self.match(bigqueryParser.T__0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Query_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def select_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Select_statementContext,0)


        def order_clause(self):
            return self.getTypedRuleContext(bigqueryParser.Order_clauseContext,0)


        def limit_clause(self):
            return self.getTypedRuleContext(bigqueryParser.Limit_clauseContext,0)


        def query_expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Query_exprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Query_exprContext,i)


        def set_op(self):
            return self.getTypedRuleContext(bigqueryParser.Set_opContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_query_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuery_expr" ):
                listener.enterQuery_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuery_expr" ):
                listener.exitQuery_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuery_expr" ):
                return visitor.visitQuery_expr(self)
            else:
                return visitor.visitChildren(self)



    def query_expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = bigqueryParser.Query_exprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_query_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 123
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.SELECT]:
                self.state = 107
                self.select_statement()
                self.state = 109
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 108
                    self.order_clause()


                self.state = 112
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                if la_ == 1:
                    self.state = 111
                    self.limit_clause()


                pass
            elif token in [bigqueryParser.T__1]:
                self.state = 114
                self.match(bigqueryParser.T__1)
                self.state = 115
                self.query_expr(0)
                self.state = 116
                self.match(bigqueryParser.T__2)
                self.state = 118
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                if la_ == 1:
                    self.state = 117
                    self.order_clause()


                self.state = 121
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                if la_ == 1:
                    self.state = 120
                    self.limit_clause()


                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 136
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = bigqueryParser.Query_exprContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_query_expr)
                    self.state = 125
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 126
                    self.set_op()
                    self.state = 127
                    self.query_expr(0)
                    self.state = 129
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        self.state = 128
                        self.order_clause()


                    self.state = 132
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
                    if la_ == 1:
                        self.state = 131
                        self.limit_clause()

             
                self.state = 138
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Select_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SELECT(self):
            return self.getToken(bigqueryParser.SELECT, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def from_statement(self):
            return self.getTypedRuleContext(bigqueryParser.From_statementContext,0)


        def where_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Where_statementContext,0)


        def group_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Group_statementContext,0)


        def having_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Having_statementContext,0)


        def ALL(self):
            return self.getToken(bigqueryParser.ALL, 0)

        def DISTINCT(self):
            return self.getToken(bigqueryParser.DISTINCT, 0)

        def alias_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Alias_nameContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Alias_nameContext,i)


        def except_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Except_statementContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Except_statementContext,i)


        def replace_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Replace_statementContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Replace_statementContext,i)


        def AS(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.AS)
            else:
                return self.getToken(bigqueryParser.AS, i)

        def getRuleIndex(self):
            return bigqueryParser.RULE_select_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelect_statement" ):
                listener.enterSelect_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelect_statement" ):
                listener.exitSelect_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelect_statement" ):
                return visitor.visitSelect_statement(self)
            else:
                return visitor.visitChildren(self)




    def select_statement(self):

        localctx = bigqueryParser.Select_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_select_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.match(bigqueryParser.SELECT)
            self.state = 141
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 140
                _la = self._input.LA(1)
                if not(_la==bigqueryParser.ALL or _la==bigqueryParser.DISTINCT):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 163
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.state = 144
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << bigqueryParser.T__1) | (1 << bigqueryParser.T__6) | (1 << bigqueryParser.T__7) | (1 << bigqueryParser.T__22) | (1 << bigqueryParser.INT) | (1 << bigqueryParser.FLOAT) | (1 << bigqueryParser.QUOTE) | (1 << bigqueryParser.DQOUTE) | (1 << bigqueryParser.ALL) | (1 << bigqueryParser.AND) | (1 << bigqueryParser.ANY) | (1 << bigqueryParser.ARRAY) | (1 << bigqueryParser.AS) | (1 << bigqueryParser.ASC) | (1 << bigqueryParser.ASSERT_ROWS_MODIFIED) | (1 << bigqueryParser.AT) | (1 << bigqueryParser.BETWEEN) | (1 << bigqueryParser.BY) | (1 << bigqueryParser.CASE) | (1 << bigqueryParser.CAST) | (1 << bigqueryParser.COLLATE) | (1 << bigqueryParser.CONTAINS) | (1 << bigqueryParser.CREATE) | (1 << bigqueryParser.CROSS) | (1 << bigqueryParser.CUBE) | (1 << bigqueryParser.CURRENT) | (1 << bigqueryParser.DEFAULT) | (1 << bigqueryParser.DEFINE) | (1 << bigqueryParser.DESC) | (1 << bigqueryParser.DISTINCT) | (1 << bigqueryParser.ELSE) | (1 << bigqueryParser.END) | (1 << bigqueryParser.ENUM) | (1 << bigqueryParser.ESCAPE) | (1 << bigqueryParser.EXCEPT) | (1 << bigqueryParser.EXCLUDE) | (1 << bigqueryParser.EXISTS) | (1 << bigqueryParser.EXTRACT) | (1 << bigqueryParser.FALSE) | (1 << bigqueryParser.FETCH) | (1 << bigqueryParser.FOLLOWING) | (1 << bigqueryParser.FOR))) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & ((1 << (bigqueryParser.FROM - 64)) | (1 << (bigqueryParser.FULL - 64)) | (1 << (bigqueryParser.GROUP - 64)) | (1 << (bigqueryParser.GROUPING - 64)) | (1 << (bigqueryParser.GROUPS - 64)) | (1 << (bigqueryParser.HASH - 64)) | (1 << (bigqueryParser.HAVING - 64)) | (1 << (bigqueryParser.IF - 64)) | (1 << (bigqueryParser.IGNORE - 64)) | (1 << (bigqueryParser.IN - 64)) | (1 << (bigqueryParser.INNER - 64)) | (1 << (bigqueryParser.INTERSECT - 64)) | (1 << (bigqueryParser.INTERVAL - 64)) | (1 << (bigqueryParser.INTO - 64)) | (1 << (bigqueryParser.IS - 64)) | (1 << (bigqueryParser.JOIN - 64)) | (1 << (bigqueryParser.LATERAL - 64)) | (1 << (bigqueryParser.LEFT - 64)) | (1 << (bigqueryParser.LIKE - 64)) | (1 << (bigqueryParser.LIMIT - 64)) | (1 << (bigqueryParser.LOOKUP - 64)) | (1 << (bigqueryParser.MERGE - 64)) | (1 << (bigqueryParser.NATURAL - 64)) | (1 << (bigqueryParser.NEW - 64)) | (1 << (bigqueryParser.NO - 64)) | (1 << (bigqueryParser.NOT - 64)) | (1 << (bigqueryParser.S_NULL - 64)) | (1 << (bigqueryParser.NULLS - 64)) | (1 << (bigqueryParser.OF - 64)) | (1 << (bigqueryParser.OFFSET - 64)) | (1 << (bigqueryParser.ON - 64)) | (1 << (bigqueryParser.OR - 64)) | (1 << (bigqueryParser.ORDER - 64)) | (1 << (bigqueryParser.ORDINAL - 64)) | (1 << (bigqueryParser.OUTER - 64)) | (1 << (bigqueryParser.OVER - 64)) | (1 << (bigqueryParser.PARTITION - 64)) | (1 << (bigqueryParser.PRECEDING - 64)) | (1 << (bigqueryParser.PROTO - 64)) | (1 << (bigqueryParser.RANGE - 64)) | (1 << (bigqueryParser.RECURSIVE - 64)) | (1 << (bigqueryParser.REPLACE - 64)) | (1 << (bigqueryParser.RESPECT - 64)) | (1 << (bigqueryParser.RIGHT - 64)) | (1 << (bigqueryParser.ROLLUP - 64)) | (1 << (bigqueryParser.ROWS - 64)) | (1 << (bigqueryParser.SAFE_OFFSET - 64)) | (1 << (bigqueryParser.SAFE_ORDINAL - 64)) | (1 << (bigqueryParser.SELECT - 64)) | (1 << (bigqueryParser.SET - 64)) | (1 << (bigqueryParser.SOME - 64)) | (1 << (bigqueryParser.SSTRUCT - 64)) | (1 << (bigqueryParser.SYSTEM - 64)) | (1 << (bigqueryParser.TABLESAMPLE - 64)) | (1 << (bigqueryParser.THEN - 64)) | (1 << (bigqueryParser.TIME - 64)) | (1 << (bigqueryParser.TO - 64)) | (1 << (bigqueryParser.TREAT - 64)) | (1 << (bigqueryParser.TRUE - 64)) | (1 << (bigqueryParser.UNBOUNDED - 64)) | (1 << (bigqueryParser.UNION - 64)) | (1 << (bigqueryParser.UNNEST - 64)) | (1 << (bigqueryParser.USING - 64)) | (1 << (bigqueryParser.WHEN - 64)))) != 0) or ((((_la - 128)) & ~0x3f) == 0 and ((1 << (_la - 128)) & ((1 << (bigqueryParser.WHERE - 128)) | (1 << (bigqueryParser.WINDOW - 128)) | (1 << (bigqueryParser.WITH - 128)) | (1 << (bigqueryParser.WITHIN - 128)) | (1 << (bigqueryParser.DAY - 128)) | (1 << (bigqueryParser.YEAR - 128)) | (1 << (bigqueryParser.MONTH - 128)) | (1 << (bigqueryParser.WEEK - 128)) | (1 << (bigqueryParser.QUARTER - 128)) | (1 << (bigqueryParser.QUOTED_STRING - 128)) | (1 << (bigqueryParser.TRIPLE_QUOTED_STRING - 128)) | (1 << (bigqueryParser.RAW_STRING - 128)) | (1 << (bigqueryParser.BYTE_STRING - 128)) | (1 << (bigqueryParser.RAW_BYTE_STRING - 128)) | (1 << (bigqueryParser.ID - 128)))) != 0):
                    self.state = 143
                    self.expr(0)


                self.state = 147
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.T__3:
                    self.state = 146
                    self.match(bigqueryParser.T__3)


                self.state = 149
                self.match(bigqueryParser.T__4)
                self.state = 151
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                if la_ == 1:
                    self.state = 150
                    self.except_statement()


                self.state = 154
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 153
                    self.replace_statement()


                pass

            elif la_ == 2:
                self.state = 156
                self.expr(0)
                self.state = 161
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
                if la_ == 1:
                    self.state = 158
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==bigqueryParser.AS:
                        self.state = 157
                        self.match(bigqueryParser.AS)


                    self.state = 160
                    self.alias_name()


                pass


            self.state = 187
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 165
                    self.match(bigqueryParser.T__5)
                    self.state = 183
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                    if la_ == 1:
                        self.state = 167
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << bigqueryParser.T__1) | (1 << bigqueryParser.T__6) | (1 << bigqueryParser.T__7) | (1 << bigqueryParser.T__22) | (1 << bigqueryParser.INT) | (1 << bigqueryParser.FLOAT) | (1 << bigqueryParser.QUOTE) | (1 << bigqueryParser.DQOUTE) | (1 << bigqueryParser.ALL) | (1 << bigqueryParser.AND) | (1 << bigqueryParser.ANY) | (1 << bigqueryParser.ARRAY) | (1 << bigqueryParser.AS) | (1 << bigqueryParser.ASC) | (1 << bigqueryParser.ASSERT_ROWS_MODIFIED) | (1 << bigqueryParser.AT) | (1 << bigqueryParser.BETWEEN) | (1 << bigqueryParser.BY) | (1 << bigqueryParser.CASE) | (1 << bigqueryParser.CAST) | (1 << bigqueryParser.COLLATE) | (1 << bigqueryParser.CONTAINS) | (1 << bigqueryParser.CREATE) | (1 << bigqueryParser.CROSS) | (1 << bigqueryParser.CUBE) | (1 << bigqueryParser.CURRENT) | (1 << bigqueryParser.DEFAULT) | (1 << bigqueryParser.DEFINE) | (1 << bigqueryParser.DESC) | (1 << bigqueryParser.DISTINCT) | (1 << bigqueryParser.ELSE) | (1 << bigqueryParser.END) | (1 << bigqueryParser.ENUM) | (1 << bigqueryParser.ESCAPE) | (1 << bigqueryParser.EXCEPT) | (1 << bigqueryParser.EXCLUDE) | (1 << bigqueryParser.EXISTS) | (1 << bigqueryParser.EXTRACT) | (1 << bigqueryParser.FALSE) | (1 << bigqueryParser.FETCH) | (1 << bigqueryParser.FOLLOWING) | (1 << bigqueryParser.FOR))) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & ((1 << (bigqueryParser.FROM - 64)) | (1 << (bigqueryParser.FULL - 64)) | (1 << (bigqueryParser.GROUP - 64)) | (1 << (bigqueryParser.GROUPING - 64)) | (1 << (bigqueryParser.GROUPS - 64)) | (1 << (bigqueryParser.HASH - 64)) | (1 << (bigqueryParser.HAVING - 64)) | (1 << (bigqueryParser.IF - 64)) | (1 << (bigqueryParser.IGNORE - 64)) | (1 << (bigqueryParser.IN - 64)) | (1 << (bigqueryParser.INNER - 64)) | (1 << (bigqueryParser.INTERSECT - 64)) | (1 << (bigqueryParser.INTERVAL - 64)) | (1 << (bigqueryParser.INTO - 64)) | (1 << (bigqueryParser.IS - 64)) | (1 << (bigqueryParser.JOIN - 64)) | (1 << (bigqueryParser.LATERAL - 64)) | (1 << (bigqueryParser.LEFT - 64)) | (1 << (bigqueryParser.LIKE - 64)) | (1 << (bigqueryParser.LIMIT - 64)) | (1 << (bigqueryParser.LOOKUP - 64)) | (1 << (bigqueryParser.MERGE - 64)) | (1 << (bigqueryParser.NATURAL - 64)) | (1 << (bigqueryParser.NEW - 64)) | (1 << (bigqueryParser.NO - 64)) | (1 << (bigqueryParser.NOT - 64)) | (1 << (bigqueryParser.S_NULL - 64)) | (1 << (bigqueryParser.NULLS - 64)) | (1 << (bigqueryParser.OF - 64)) | (1 << (bigqueryParser.OFFSET - 64)) | (1 << (bigqueryParser.ON - 64)) | (1 << (bigqueryParser.OR - 64)) | (1 << (bigqueryParser.ORDER - 64)) | (1 << (bigqueryParser.ORDINAL - 64)) | (1 << (bigqueryParser.OUTER - 64)) | (1 << (bigqueryParser.OVER - 64)) | (1 << (bigqueryParser.PARTITION - 64)) | (1 << (bigqueryParser.PRECEDING - 64)) | (1 << (bigqueryParser.PROTO - 64)) | (1 << (bigqueryParser.RANGE - 64)) | (1 << (bigqueryParser.RECURSIVE - 64)) | (1 << (bigqueryParser.REPLACE - 64)) | (1 << (bigqueryParser.RESPECT - 64)) | (1 << (bigqueryParser.RIGHT - 64)) | (1 << (bigqueryParser.ROLLUP - 64)) | (1 << (bigqueryParser.ROWS - 64)) | (1 << (bigqueryParser.SAFE_OFFSET - 64)) | (1 << (bigqueryParser.SAFE_ORDINAL - 64)) | (1 << (bigqueryParser.SELECT - 64)) | (1 << (bigqueryParser.SET - 64)) | (1 << (bigqueryParser.SOME - 64)) | (1 << (bigqueryParser.SSTRUCT - 64)) | (1 << (bigqueryParser.SYSTEM - 64)) | (1 << (bigqueryParser.TABLESAMPLE - 64)) | (1 << (bigqueryParser.THEN - 64)) | (1 << (bigqueryParser.TIME - 64)) | (1 << (bigqueryParser.TO - 64)) | (1 << (bigqueryParser.TREAT - 64)) | (1 << (bigqueryParser.TRUE - 64)) | (1 << (bigqueryParser.UNBOUNDED - 64)) | (1 << (bigqueryParser.UNION - 64)) | (1 << (bigqueryParser.UNNEST - 64)) | (1 << (bigqueryParser.USING - 64)) | (1 << (bigqueryParser.WHEN - 64)))) != 0) or ((((_la - 128)) & ~0x3f) == 0 and ((1 << (_la - 128)) & ((1 << (bigqueryParser.WHERE - 128)) | (1 << (bigqueryParser.WINDOW - 128)) | (1 << (bigqueryParser.WITH - 128)) | (1 << (bigqueryParser.WITHIN - 128)) | (1 << (bigqueryParser.DAY - 128)) | (1 << (bigqueryParser.YEAR - 128)) | (1 << (bigqueryParser.MONTH - 128)) | (1 << (bigqueryParser.WEEK - 128)) | (1 << (bigqueryParser.QUARTER - 128)) | (1 << (bigqueryParser.QUOTED_STRING - 128)) | (1 << (bigqueryParser.TRIPLE_QUOTED_STRING - 128)) | (1 << (bigqueryParser.RAW_STRING - 128)) | (1 << (bigqueryParser.BYTE_STRING - 128)) | (1 << (bigqueryParser.RAW_BYTE_STRING - 128)) | (1 << (bigqueryParser.ID - 128)))) != 0):
                            self.state = 166
                            self.expr(0)


                        self.state = 169
                        self.match(bigqueryParser.T__4)
                        self.state = 171
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                        if la_ == 1:
                            self.state = 170
                            self.except_statement()


                        self.state = 174
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                        if la_ == 1:
                            self.state = 173
                            self.replace_statement()


                        pass

                    elif la_ == 2:
                        self.state = 176
                        self.expr(0)
                        self.state = 181
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                        if la_ == 1:
                            self.state = 178
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            if _la==bigqueryParser.AS:
                                self.state = 177
                                self.match(bigqueryParser.AS)


                            self.state = 180
                            self.alias_name()


                        pass

             
                self.state = 189
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

            self.state = 191
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 190
                self.from_statement()


            self.state = 194
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                self.state = 193
                self.where_statement()


            self.state = 197
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.state = 196
                self.group_statement()


            self.state = 200
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.state = 199
                self.having_statement()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class From_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FROM(self):
            return self.getToken(bigqueryParser.FROM, 0)

        def from_item(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.From_itemContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.From_itemContext,i)


        def getRuleIndex(self):
            return bigqueryParser.RULE_from_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrom_statement" ):
                listener.enterFrom_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrom_statement" ):
                listener.exitFrom_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrom_statement" ):
                return visitor.visitFrom_statement(self)
            else:
                return visitor.visitChildren(self)




    def from_statement(self):

        localctx = bigqueryParser.From_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_from_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.match(bigqueryParser.FROM)
            self.state = 203
            self.from_item(0)
            self.state = 208
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,28,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 204
                    self.match(bigqueryParser.T__5)
                    self.state = 205
                    self.from_item(0) 
                self.state = 210
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class From_itemContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def table_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Table_exprContext,0)


        def alias_name(self):
            return self.getTypedRuleContext(bigqueryParser.Alias_nameContext,0)


        def FOR(self):
            return self.getToken(bigqueryParser.FOR, 0)

        def SYSTEM(self):
            return self.getToken(bigqueryParser.SYSTEM, 0)

        def TIME(self):
            return self.getToken(bigqueryParser.TIME, 0)

        def AS(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.AS)
            else:
                return self.getToken(bigqueryParser.AS, i)

        def OF(self):
            return self.getToken(bigqueryParser.OF, 0)

        def string(self):
            return self.getTypedRuleContext(bigqueryParser.StringContext,0)


        def query_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Query_statementContext,0)


        def from_item(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.From_itemContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.From_itemContext,i)


        def JOIN(self):
            return self.getToken(bigqueryParser.JOIN, 0)

        def on_clause(self):
            return self.getTypedRuleContext(bigqueryParser.On_clauseContext,0)


        def using_clause(self):
            return self.getTypedRuleContext(bigqueryParser.Using_clauseContext,0)


        def join_type(self):
            return self.getTypedRuleContext(bigqueryParser.Join_typeContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_from_item

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrom_item" ):
                listener.enterFrom_item(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrom_item" ):
                listener.exitFrom_item(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrom_item" ):
                return visitor.visitFrom_item(self)
            else:
                return visitor.visitChildren(self)



    def from_item(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = bigqueryParser.From_itemContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_from_item, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 236
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.state = 212
                self.table_expr()
                self.state = 217
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
                if la_ == 1:
                    self.state = 214
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==bigqueryParser.AS:
                        self.state = 213
                        self.match(bigqueryParser.AS)


                    self.state = 216
                    self.alias_name()


                self.state = 225
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                if la_ == 1:
                    self.state = 219
                    self.match(bigqueryParser.FOR)
                    self.state = 220
                    self.match(bigqueryParser.SYSTEM)
                    self.state = 221
                    self.match(bigqueryParser.TIME)
                    self.state = 222
                    self.match(bigqueryParser.AS)
                    self.state = 223
                    self.match(bigqueryParser.OF)
                    self.state = 224
                    self.string()


                pass

            elif la_ == 2:
                self.state = 227
                self.match(bigqueryParser.T__1)
                self.state = 228
                self.query_statement()
                self.state = 229
                self.match(bigqueryParser.T__2)
                self.state = 234
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
                if la_ == 1:
                    self.state = 231
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==bigqueryParser.AS:
                        self.state = 230
                        self.match(bigqueryParser.AS)


                    self.state = 233
                    self.alias_name()


                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 250
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,37,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = bigqueryParser.From_itemContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_from_item)
                    self.state = 238
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 240
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if ((((_la - 45)) & ~0x3f) == 0 and ((1 << (_la - 45)) & ((1 << (bigqueryParser.CROSS - 45)) | (1 << (bigqueryParser.FULL - 45)) | (1 << (bigqueryParser.INNER - 45)) | (1 << (bigqueryParser.LEFT - 45)) | (1 << (bigqueryParser.RIGHT - 45)))) != 0):
                        self.state = 239
                        self.join_type()


                    self.state = 242
                    self.match(bigqueryParser.JOIN)
                    self.state = 243
                    self.from_item(0)
                    self.state = 246
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [bigqueryParser.ON]:
                        self.state = 244
                        self.on_clause()
                        pass
                    elif token in [bigqueryParser.USING]:
                        self.state = 245
                        self.using_clause()
                        pass
                    else:
                        raise NoViableAltException(self)
             
                self.state = 252
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Where_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHERE(self):
            return self.getToken(bigqueryParser.WHERE, 0)

        def bool_expression(self):
            return self.getTypedRuleContext(bigqueryParser.Bool_expressionContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_where_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhere_statement" ):
                listener.enterWhere_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhere_statement" ):
                listener.exitWhere_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhere_statement" ):
                return visitor.visitWhere_statement(self)
            else:
                return visitor.visitChildren(self)




    def where_statement(self):

        localctx = bigqueryParser.Where_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_where_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253
            self.match(bigqueryParser.WHERE)
            self.state = 254
            self.bool_expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Group_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(bigqueryParser.GROUP, 0)

        def BY(self):
            return self.getToken(bigqueryParser.BY, 0)

        def ROLLUP(self):
            return self.getToken(bigqueryParser.ROLLUP, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def getRuleIndex(self):
            return bigqueryParser.RULE_group_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroup_statement" ):
                listener.enterGroup_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroup_statement" ):
                listener.exitGroup_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGroup_statement" ):
                return visitor.visitGroup_statement(self)
            else:
                return visitor.visitChildren(self)




    def group_statement(self):

        localctx = bigqueryParser.Group_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_group_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 256
            self.match(bigqueryParser.GROUP)
            self.state = 257
            self.match(bigqueryParser.BY)
            self.state = 278
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 258
                self.expr(0)
                self.state = 263
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 259
                        self.match(bigqueryParser.T__5)
                        self.state = 260
                        self.expr(0) 
                    self.state = 265
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

                pass

            elif la_ == 2:
                self.state = 266
                self.match(bigqueryParser.ROLLUP)
                self.state = 267
                self.match(bigqueryParser.T__1)
                self.state = 268
                self.expr(0)
                self.state = 273
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==bigqueryParser.T__5:
                    self.state = 269
                    self.match(bigqueryParser.T__5)
                    self.state = 270
                    self.expr(0)
                    self.state = 275
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 276
                self.match(bigqueryParser.T__2)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Having_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HAVING(self):
            return self.getToken(bigqueryParser.HAVING, 0)

        def bool_expression(self):
            return self.getTypedRuleContext(bigqueryParser.Bool_expressionContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_having_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHaving_statement" ):
                listener.enterHaving_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHaving_statement" ):
                listener.exitHaving_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitHaving_statement" ):
                return visitor.visitHaving_statement(self)
            else:
                return visitor.visitChildren(self)




    def having_statement(self):

        localctx = bigqueryParser.Having_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_having_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 280
            self.match(bigqueryParser.HAVING)
            self.state = 281
            self.bool_expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Order_clauseContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ORDER(self):
            return self.getToken(bigqueryParser.ORDER, 0)

        def BY(self):
            return self.getToken(bigqueryParser.BY, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def ASC(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.ASC)
            else:
                return self.getToken(bigqueryParser.ASC, i)

        def DESC(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.DESC)
            else:
                return self.getToken(bigqueryParser.DESC, i)

        def getRuleIndex(self):
            return bigqueryParser.RULE_order_clause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrder_clause" ):
                listener.enterOrder_clause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrder_clause" ):
                listener.exitOrder_clause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOrder_clause" ):
                return visitor.visitOrder_clause(self)
            else:
                return visitor.visitChildren(self)




    def order_clause(self):

        localctx = bigqueryParser.Order_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_order_clause)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 283
            self.match(bigqueryParser.ORDER)
            self.state = 284
            self.match(bigqueryParser.BY)
            self.state = 285
            self.expr(0)
            self.state = 287
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
            if la_ == 1:
                self.state = 286
                _la = self._input.LA(1)
                if not(_la==bigqueryParser.ASC or _la==bigqueryParser.DESC):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 296
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,43,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 289
                    self.match(bigqueryParser.T__5)
                    self.state = 290
                    self.expr(0)
                    self.state = 292
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
                    if la_ == 1:
                        self.state = 291
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.ASC or _la==bigqueryParser.DESC):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()

             
                self.state = 298
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,43,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Limit_clauseContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LIMIT(self):
            return self.getToken(bigqueryParser.LIMIT, 0)

        def count(self):
            return self.getTypedRuleContext(bigqueryParser.CountContext,0)


        def OFFSET(self):
            return self.getToken(bigqueryParser.OFFSET, 0)

        def skip_rows(self):
            return self.getTypedRuleContext(bigqueryParser.Skip_rowsContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_limit_clause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLimit_clause" ):
                listener.enterLimit_clause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLimit_clause" ):
                listener.exitLimit_clause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLimit_clause" ):
                return visitor.visitLimit_clause(self)
            else:
                return visitor.visitChildren(self)




    def limit_clause(self):

        localctx = bigqueryParser.Limit_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_limit_clause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 299
            self.match(bigqueryParser.LIMIT)
            self.state = 300
            self.count()
            self.state = 303
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,44,self._ctx)
            if la_ == 1:
                self.state = 301
                self.match(bigqueryParser.OFFSET)
                self.state = 302
                self.skip_rows()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unary_operatorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(bigqueryParser.NOT, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_unary_operator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnary_operator" ):
                listener.enterUnary_operator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnary_operator" ):
                listener.exitUnary_operator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnary_operator" ):
                return visitor.visitUnary_operator(self)
            else:
                return visitor.visitChildren(self)




    def unary_operator(self):

        localctx = bigqueryParser.Unary_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_unary_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            _la = self._input.LA(1)
            if not(_la==bigqueryParser.T__6 or _la==bigqueryParser.T__7 or _la==bigqueryParser.NOT):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return bigqueryParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class Expr_CaseContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CASE(self):
            return self.getToken(bigqueryParser.CASE, 0)
        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)

        def case_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Case_exprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Case" ):
                listener.enterExpr_Case(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Case" ):
                listener.exitExpr_Case(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Case" ):
                return visitor.visitExpr_Case(self)
            else:
                return visitor.visitChildren(self)


    class Expr_UnaryContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def unary_operator(self):
            return self.getTypedRuleContext(bigqueryParser.Unary_operatorContext,0)

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Unary" ):
                listener.enterExpr_Unary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Unary" ):
                listener.exitExpr_Unary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Unary" ):
                return visitor.visitExpr_Unary(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_InContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def IN(self):
            return self.getToken(bigqueryParser.IN, 0)
        def NOT(self):
            return self.getToken(bigqueryParser.NOT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_In" ):
                listener.enterExpr_Bool_In(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_In" ):
                listener.exitExpr_Bool_In(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_In" ):
                return visitor.visitExpr_Bool_In(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Binary2Context(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Binary2" ):
                listener.enterExpr_Binary2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Binary2" ):
                listener.exitExpr_Binary2(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Binary2" ):
                return visitor.visitExpr_Binary2(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Binary1Context(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Binary1" ):
                listener.enterExpr_Binary1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Binary1" ):
                listener.exitExpr_Binary1(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Binary1" ):
                return visitor.visitExpr_Binary1(self)
            else:
                return visitor.visitChildren(self)


    class Expr_NumberContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def number(self):
            return self.getTypedRuleContext(bigqueryParser.NumberContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Number" ):
                listener.enterExpr_Number(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Number" ):
                listener.exitExpr_Number(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Number" ):
                return visitor.visitExpr_Number(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_IsContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)

        def IS(self):
            return self.getToken(bigqueryParser.IS, 0)
        def S_NULL(self):
            return self.getToken(bigqueryParser.S_NULL, 0)
        def TRUE(self):
            return self.getToken(bigqueryParser.TRUE, 0)
        def FALSE(self):
            return self.getToken(bigqueryParser.FALSE, 0)
        def NOT(self):
            return self.getToken(bigqueryParser.NOT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_Is" ):
                listener.enterExpr_Bool_Is(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_Is" ):
                listener.exitExpr_Bool_Is(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_Is" ):
                return visitor.visitExpr_Bool_Is(self)
            else:
                return visitor.visitChildren(self)


    class Expr_RelationalContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def LIKE(self):
            return self.getToken(bigqueryParser.LIKE, 0)
        def BETWEEN(self):
            return self.getToken(bigqueryParser.BETWEEN, 0)
        def AND(self):
            return self.getToken(bigqueryParser.AND, 0)
        def NOT(self):
            return self.getToken(bigqueryParser.NOT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Relational" ):
                listener.enterExpr_Relational(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Relational" ):
                listener.exitExpr_Relational(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Relational" ):
                return visitor.visitExpr_Relational(self)
            else:
                return visitor.visitChildren(self)


    class Expr_StringContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def string(self):
            return self.getTypedRuleContext(bigqueryParser.StringContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_String" ):
                listener.enterExpr_String(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_String" ):
                listener.exitExpr_String(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_String" ):
                return visitor.visitExpr_String(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Function_GenericContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def function_name(self):
            return self.getTypedRuleContext(bigqueryParser.Function_nameContext,0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def FROM(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.FROM)
            else:
                return self.getToken(bigqueryParser.FROM, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Function_Generic" ):
                listener.enterExpr_Function_Generic(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Function_Generic" ):
                listener.exitExpr_Function_Generic(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Function_Generic" ):
                return visitor.visitExpr_Function_Generic(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_AndContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def AND(self):
            return self.getToken(bigqueryParser.AND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_And" ):
                listener.enterExpr_Bool_And(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_And" ):
                listener.exitExpr_Bool_And(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_And" ):
                return visitor.visitExpr_Bool_And(self)
            else:
                return visitor.visitChildren(self)


    class Expr_BracketedContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bracketed" ):
                listener.enterExpr_Bracketed(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bracketed" ):
                listener.exitExpr_Bracketed(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bracketed" ):
                return visitor.visitExpr_Bracketed(self)
            else:
                return visitor.visitChildren(self)


    class Expr_ArrowContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Arrow" ):
                listener.enterExpr_Arrow(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Arrow" ):
                listener.exitExpr_Arrow(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Arrow" ):
                return visitor.visitExpr_Arrow(self)
            else:
                return visitor.visitChildren(self)


    class Expr_CastContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def cast_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Cast_exprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Cast" ):
                listener.enterExpr_Cast(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Cast" ):
                listener.exitExpr_Cast(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Cast" ):
                return visitor.visitExpr_Cast(self)
            else:
                return visitor.visitChildren(self)


    class Expr_KeywordContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def keyword(self):
            return self.getTypedRuleContext(bigqueryParser.KeywordContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Keyword" ):
                listener.enterExpr_Keyword(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Keyword" ):
                listener.exitExpr_Keyword(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Keyword" ):
                return visitor.visitExpr_Keyword(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_PipeContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_Pipe" ):
                listener.enterExpr_Bool_Pipe(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_Pipe" ):
                listener.exitExpr_Bool_Pipe(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_Pipe" ):
                return visitor.visitExpr_Bool_Pipe(self)
            else:
                return visitor.visitChildren(self)


    class Expr_IntervalContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def interval_delta(self):
            return self.getTypedRuleContext(bigqueryParser.Interval_deltaContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Interval" ):
                listener.enterExpr_Interval(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Interval" ):
                listener.exitExpr_Interval(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Interval" ):
                return visitor.visitExpr_Interval(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_CaretContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_Caret" ):
                listener.enterExpr_Bool_Caret(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_Caret" ):
                listener.exitExpr_Bool_Caret(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_Caret" ):
                return visitor.visitExpr_Bool_Caret(self)
            else:
                return visitor.visitChildren(self)


    class Expr_DqlContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def select_statement(self):
            return self.getTypedRuleContext(bigqueryParser.Select_statementContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Dql" ):
                listener.enterExpr_Dql(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Dql" ):
                listener.exitExpr_Dql(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Dql" ):
                return visitor.visitExpr_Dql(self)
            else:
                return visitor.visitChildren(self)


    class Expr_ColumnContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def column_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Column_exprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Column" ):
                listener.enterExpr_Column(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Column" ):
                listener.exitExpr_Column(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Column" ):
                return visitor.visitExpr_Column(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_OrContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def OR(self):
            return self.getToken(bigqueryParser.OR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_Or" ):
                listener.enterExpr_Bool_Or(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_Or" ):
                listener.exitExpr_Bool_Or(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_Or" ):
                return visitor.visitExpr_Bool_Or(self)
            else:
                return visitor.visitChildren(self)


    class Expr_Bool_AmpContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr_Bool_Amp" ):
                listener.enterExpr_Bool_Amp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr_Bool_Amp" ):
                listener.exitExpr_Bool_Amp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr_Bool_Amp" ):
                return visitor.visitExpr_Bool_Amp(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = bigqueryParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 22
        self.enterRecursionRule(localctx, 22, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 340
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                localctx = bigqueryParser.Expr_NumberContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 308
                self.number()
                pass

            elif la_ == 2:
                localctx = bigqueryParser.Expr_StringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 309
                self.string()
                pass

            elif la_ == 3:
                localctx = bigqueryParser.Expr_DqlContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 310
                self.select_statement()
                pass

            elif la_ == 4:
                localctx = bigqueryParser.Expr_UnaryContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 311
                self.unary_operator()
                self.state = 312
                self.expr(20)
                pass

            elif la_ == 5:
                localctx = bigqueryParser.Expr_CaseContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 314
                self.match(bigqueryParser.CASE)

                self.state = 315
                self.expr(0)
                pass

            elif la_ == 6:
                localctx = bigqueryParser.Expr_Function_GenericContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 316
                self.function_name()
                self.state = 317
                self.match(bigqueryParser.T__1)
                self.state = 327
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [bigqueryParser.T__1, bigqueryParser.T__6, bigqueryParser.T__7, bigqueryParser.T__22, bigqueryParser.INT, bigqueryParser.FLOAT, bigqueryParser.QUOTE, bigqueryParser.DQOUTE, bigqueryParser.ALL, bigqueryParser.AND, bigqueryParser.ANY, bigqueryParser.ARRAY, bigqueryParser.AS, bigqueryParser.ASC, bigqueryParser.ASSERT_ROWS_MODIFIED, bigqueryParser.AT, bigqueryParser.BETWEEN, bigqueryParser.BY, bigqueryParser.CASE, bigqueryParser.CAST, bigqueryParser.COLLATE, bigqueryParser.CONTAINS, bigqueryParser.CREATE, bigqueryParser.CROSS, bigqueryParser.CUBE, bigqueryParser.CURRENT, bigqueryParser.DEFAULT, bigqueryParser.DEFINE, bigqueryParser.DESC, bigqueryParser.DISTINCT, bigqueryParser.ELSE, bigqueryParser.END, bigqueryParser.ENUM, bigqueryParser.ESCAPE, bigqueryParser.EXCEPT, bigqueryParser.EXCLUDE, bigqueryParser.EXISTS, bigqueryParser.EXTRACT, bigqueryParser.FALSE, bigqueryParser.FETCH, bigqueryParser.FOLLOWING, bigqueryParser.FOR, bigqueryParser.FROM, bigqueryParser.FULL, bigqueryParser.GROUP, bigqueryParser.GROUPING, bigqueryParser.GROUPS, bigqueryParser.HASH, bigqueryParser.HAVING, bigqueryParser.IF, bigqueryParser.IGNORE, bigqueryParser.IN, bigqueryParser.INNER, bigqueryParser.INTERSECT, bigqueryParser.INTERVAL, bigqueryParser.INTO, bigqueryParser.IS, bigqueryParser.JOIN, bigqueryParser.LATERAL, bigqueryParser.LEFT, bigqueryParser.LIKE, bigqueryParser.LIMIT, bigqueryParser.LOOKUP, bigqueryParser.MERGE, bigqueryParser.NATURAL, bigqueryParser.NEW, bigqueryParser.NO, bigqueryParser.NOT, bigqueryParser.S_NULL, bigqueryParser.NULLS, bigqueryParser.OF, bigqueryParser.OFFSET, bigqueryParser.ON, bigqueryParser.OR, bigqueryParser.ORDER, bigqueryParser.ORDINAL, bigqueryParser.OUTER, bigqueryParser.OVER, bigqueryParser.PARTITION, bigqueryParser.PRECEDING, bigqueryParser.PROTO, bigqueryParser.RANGE, bigqueryParser.RECURSIVE, bigqueryParser.REPLACE, bigqueryParser.RESPECT, bigqueryParser.RIGHT, bigqueryParser.ROLLUP, bigqueryParser.ROWS, bigqueryParser.SAFE_OFFSET, bigqueryParser.SAFE_ORDINAL, bigqueryParser.SELECT, bigqueryParser.SET, bigqueryParser.SOME, bigqueryParser.SSTRUCT, bigqueryParser.SYSTEM, bigqueryParser.TABLESAMPLE, bigqueryParser.THEN, bigqueryParser.TIME, bigqueryParser.TO, bigqueryParser.TREAT, bigqueryParser.TRUE, bigqueryParser.UNBOUNDED, bigqueryParser.UNION, bigqueryParser.UNNEST, bigqueryParser.USING, bigqueryParser.WHEN, bigqueryParser.WHERE, bigqueryParser.WINDOW, bigqueryParser.WITH, bigqueryParser.WITHIN, bigqueryParser.DAY, bigqueryParser.YEAR, bigqueryParser.MONTH, bigqueryParser.WEEK, bigqueryParser.QUARTER, bigqueryParser.QUOTED_STRING, bigqueryParser.TRIPLE_QUOTED_STRING, bigqueryParser.RAW_STRING, bigqueryParser.BYTE_STRING, bigqueryParser.RAW_BYTE_STRING, bigqueryParser.ID]:
                    self.state = 318
                    self.expr(0)
                    self.state = 323
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==bigqueryParser.T__5 or _la==bigqueryParser.FROM:
                        self.state = 319
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.T__5 or _la==bigqueryParser.FROM):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 320
                        self.expr(0)
                        self.state = 325
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    pass
                elif token in [bigqueryParser.T__4]:
                    self.state = 326
                    self.match(bigqueryParser.T__4)
                    pass
                elif token in [bigqueryParser.T__2]:
                    pass
                else:
                    pass
                self.state = 329
                self.match(bigqueryParser.T__2)
                pass

            elif la_ == 7:
                localctx = bigqueryParser.Expr_CastContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 331
                self.cast_expr()
                pass

            elif la_ == 8:
                localctx = bigqueryParser.Expr_CaseContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 332
                self.case_expr()
                pass

            elif la_ == 9:
                localctx = bigqueryParser.Expr_IntervalContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 333
                self.interval_delta()
                pass

            elif la_ == 10:
                localctx = bigqueryParser.Expr_BracketedContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 334
                self.match(bigqueryParser.T__1)
                self.state = 335
                self.expr(0)
                self.state = 336
                self.match(bigqueryParser.T__2)
                pass

            elif la_ == 11:
                localctx = bigqueryParser.Expr_ColumnContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 338
                self.column_expr()
                pass

            elif la_ == 12:
                localctx = bigqueryParser.Expr_KeywordContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 339
                self.keyword()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 413
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,55,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 411
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
                    if la_ == 1:
                        localctx = bigqueryParser.Expr_Binary1Context(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 342
                        if not self.precpred(self._ctx, 19):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 19)")
                        self.state = 343
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.T__4 or _la==bigqueryParser.T__8):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 344
                        self.expr(20)
                        pass

                    elif la_ == 2:
                        localctx = bigqueryParser.Expr_Binary2Context(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 345
                        if not self.precpred(self._ctx, 18):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 18)")
                        self.state = 346
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.T__6 or _la==bigqueryParser.T__9):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 347
                        self.expr(19)
                        pass

                    elif la_ == 3:
                        localctx = bigqueryParser.Expr_ArrowContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 348
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 349
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.T__10 or _la==bigqueryParser.T__11):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 350
                        self.expr(18)
                        pass

                    elif la_ == 4:
                        localctx = bigqueryParser.Expr_Bool_AmpContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 351
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 352
                        self.match(bigqueryParser.T__12)
                        self.state = 353
                        self.expr(17)
                        pass

                    elif la_ == 5:
                        localctx = bigqueryParser.Expr_Bool_CaretContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 354
                        if not self.precpred(self._ctx, 15):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 15)")
                        self.state = 355
                        self.match(bigqueryParser.T__13)
                        self.state = 356
                        self.expr(16)
                        pass

                    elif la_ == 6:
                        localctx = bigqueryParser.Expr_Bool_PipeContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 357
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 358
                        self.match(bigqueryParser.T__14)
                        self.state = 359
                        self.expr(15)
                        pass

                    elif la_ == 7:
                        localctx = bigqueryParser.Expr_RelationalContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 360
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 380
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
                        if la_ == 1:
                            self.state = 361
                            self.match(bigqueryParser.T__15)
                            pass

                        elif la_ == 2:
                            self.state = 362
                            self.match(bigqueryParser.T__16)
                            pass

                        elif la_ == 3:
                            self.state = 363
                            self.match(bigqueryParser.T__17)
                            pass

                        elif la_ == 4:
                            self.state = 364
                            self.match(bigqueryParser.T__18)
                            pass

                        elif la_ == 5:
                            self.state = 365
                            self.match(bigqueryParser.T__19)
                            pass

                        elif la_ == 6:
                            self.state = 366
                            self.match(bigqueryParser.T__20)
                            pass

                        elif la_ == 7:
                            self.state = 367
                            self.match(bigqueryParser.T__21)
                            pass

                        elif la_ == 8:
                            self.state = 369
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            if _la==bigqueryParser.NOT:
                                self.state = 368
                                self.match(bigqueryParser.NOT)


                            self.state = 371
                            self.match(bigqueryParser.LIKE)
                            pass

                        elif la_ == 9:
                            self.state = 373
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            if _la==bigqueryParser.NOT:
                                self.state = 372
                                self.match(bigqueryParser.NOT)


                            self.state = 375
                            self.match(bigqueryParser.BETWEEN)
                            self.state = 376
                            self.expr(0)
                            self.state = 377
                            self.match(bigqueryParser.AND)
                            self.state = 378
                            self.expr(0)
                            pass


                        self.state = 382
                        self.expr(13)
                        pass

                    elif la_ == 8:
                        localctx = bigqueryParser.Expr_Bool_AndContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 383
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 384
                        self.match(bigqueryParser.AND)
                        self.state = 385
                        self.expr(10)
                        pass

                    elif la_ == 9:
                        localctx = bigqueryParser.Expr_Bool_OrContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 386
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 387
                        self.match(bigqueryParser.OR)
                        self.state = 388
                        self.expr(9)
                        pass

                    elif la_ == 10:
                        localctx = bigqueryParser.Expr_Bool_IsContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 389
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 390
                        self.match(bigqueryParser.IS)
                        self.state = 392
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==bigqueryParser.NOT:
                            self.state = 391
                            self.match(bigqueryParser.NOT)


                        self.state = 394
                        _la = self._input.LA(1)
                        if not(((((_la - 60)) & ~0x3f) == 0 and ((1 << (_la - 60)) & ((1 << (bigqueryParser.FALSE - 60)) | (1 << (bigqueryParser.S_NULL - 60)) | (1 << (bigqueryParser.TRUE - 60)))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        pass

                    elif la_ == 11:
                        localctx = bigqueryParser.Expr_Bool_InContext(self, bigqueryParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 395
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 397
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==bigqueryParser.NOT:
                            self.state = 396
                            self.match(bigqueryParser.NOT)


                        self.state = 399
                        self.match(bigqueryParser.IN)

                        self.state = 400
                        self.match(bigqueryParser.T__1)
                        self.state = 401
                        self.expr(0)
                        self.state = 406
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while _la==bigqueryParser.T__5:
                            self.state = 402
                            self.match(bigqueryParser.T__5)
                            self.state = 403
                            self.expr(0)
                            self.state = 408
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 409
                        self.match(bigqueryParser.T__2)
                        pass

             
                self.state = 415
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,55,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Case_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return bigqueryParser.RULE_case_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class Case_SearchedContext(Case_exprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.Case_exprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CASE(self):
            return self.getToken(bigqueryParser.CASE, 0)
        def END(self):
            return self.getToken(bigqueryParser.END, 0)
        def switch_search_condition_section(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Switch_search_condition_sectionContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Switch_search_condition_sectionContext,i)

        def ELSE(self):
            return self.getToken(bigqueryParser.ELSE, 0)
        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCase_Searched" ):
                listener.enterCase_Searched(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCase_Searched" ):
                listener.exitCase_Searched(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCase_Searched" ):
                return visitor.visitCase_Searched(self)
            else:
                return visitor.visitChildren(self)


    class Case_SwitchedContext(Case_exprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a bigqueryParser.Case_exprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CASE(self):
            return self.getToken(bigqueryParser.CASE, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)

        def END(self):
            return self.getToken(bigqueryParser.END, 0)
        def switch_section(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Switch_sectionContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Switch_sectionContext,i)

        def ELSE(self):
            return self.getToken(bigqueryParser.ELSE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCase_Switched" ):
                listener.enterCase_Switched(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCase_Switched" ):
                listener.exitCase_Switched(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCase_Switched" ):
                return visitor.visitCase_Switched(self)
            else:
                return visitor.visitChildren(self)



    def case_expr(self):

        localctx = bigqueryParser.Case_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_case_expr)
        self._la = 0 # Token type
        try:
            self.state = 441
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,60,self._ctx)
            if la_ == 1:
                localctx = bigqueryParser.Case_SwitchedContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 416
                self.match(bigqueryParser.CASE)
                self.state = 417
                self.expr(0)
                self.state = 419 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 418
                    self.switch_section()
                    self.state = 421 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==bigqueryParser.WHEN):
                        break

                self.state = 425
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.ELSE:
                    self.state = 423
                    self.match(bigqueryParser.ELSE)
                    self.state = 424
                    self.expr(0)


                self.state = 427
                self.match(bigqueryParser.END)
                pass

            elif la_ == 2:
                localctx = bigqueryParser.Case_SearchedContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 429
                self.match(bigqueryParser.CASE)
                self.state = 431 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 430
                    self.switch_search_condition_section()
                    self.state = 433 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==bigqueryParser.WHEN):
                        break

                self.state = 437
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.ELSE:
                    self.state = 435
                    self.match(bigqueryParser.ELSE)
                    self.state = 436
                    self.expr(0)


                self.state = 439
                self.match(bigqueryParser.END)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Switch_sectionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHEN(self):
            return self.getToken(bigqueryParser.WHEN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def THEN(self):
            return self.getToken(bigqueryParser.THEN, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_switch_section

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSwitch_section" ):
                listener.enterSwitch_section(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSwitch_section" ):
                listener.exitSwitch_section(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSwitch_section" ):
                return visitor.visitSwitch_section(self)
            else:
                return visitor.visitChildren(self)




    def switch_section(self):

        localctx = bigqueryParser.Switch_sectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_switch_section)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 443
            self.match(bigqueryParser.WHEN)
            self.state = 444
            self.expr(0)
            self.state = 445
            self.match(bigqueryParser.THEN)
            self.state = 446
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Switch_search_condition_sectionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHEN(self):
            return self.getToken(bigqueryParser.WHEN, 0)

        def bool_expression(self):
            return self.getTypedRuleContext(bigqueryParser.Bool_expressionContext,0)


        def THEN(self):
            return self.getToken(bigqueryParser.THEN, 0)

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_switch_search_condition_section

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSwitch_search_condition_section" ):
                listener.enterSwitch_search_condition_section(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSwitch_search_condition_section" ):
                listener.exitSwitch_search_condition_section(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSwitch_search_condition_section" ):
                return visitor.visitSwitch_search_condition_section(self)
            else:
                return visitor.visitChildren(self)




    def switch_search_condition_section(self):

        localctx = bigqueryParser.Switch_search_condition_sectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_switch_search_condition_section)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.match(bigqueryParser.WHEN)
            self.state = 449
            self.bool_expression()
            self.state = 450
            self.match(bigqueryParser.THEN)
            self.state = 451
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Interval_deltaContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTERVAL(self):
            return self.getToken(bigqueryParser.INTERVAL, 0)

        def integer_type(self):
            return self.getTypedRuleContext(bigqueryParser.Integer_typeContext,0)


        def DAY(self):
            return self.getToken(bigqueryParser.DAY, 0)

        def YEAR(self):
            return self.getToken(bigqueryParser.YEAR, 0)

        def MONTH(self):
            return self.getToken(bigqueryParser.MONTH, 0)

        def WEEK(self):
            return self.getToken(bigqueryParser.WEEK, 0)

        def QUARTER(self):
            return self.getToken(bigqueryParser.QUARTER, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_interval_delta

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInterval_delta" ):
                listener.enterInterval_delta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInterval_delta" ):
                listener.exitInterval_delta(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInterval_delta" ):
                return visitor.visitInterval_delta(self)
            else:
                return visitor.visitChildren(self)




    def interval_delta(self):

        localctx = bigqueryParser.Interval_deltaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_interval_delta)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 453
            self.match(bigqueryParser.INTERVAL)
            self.state = 454
            self.integer_type()
            self.state = 455
            _la = self._input.LA(1)
            if not(((((_la - 132)) & ~0x3f) == 0 and ((1 << (_la - 132)) & ((1 << (bigqueryParser.DAY - 132)) | (1 << (bigqueryParser.YEAR - 132)) | (1 << (bigqueryParser.MONTH - 132)) | (1 << (bigqueryParser.WEEK - 132)) | (1 << (bigqueryParser.QUARTER - 132)))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cast_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CAST(self):
            return self.getToken(bigqueryParser.CAST, 0)

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def AS(self):
            return self.getToken(bigqueryParser.AS, 0)

        def datatype_name(self):
            return self.getTypedRuleContext(bigqueryParser.Datatype_nameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_cast_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCast_expr" ):
                listener.enterCast_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCast_expr" ):
                listener.exitCast_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCast_expr" ):
                return visitor.visitCast_expr(self)
            else:
                return visitor.visitChildren(self)




    def cast_expr(self):

        localctx = bigqueryParser.Cast_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_cast_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 457
            self.match(bigqueryParser.CAST)
            self.state = 458
            self.match(bigqueryParser.T__1)
            self.state = 459
            self.expr(0)
            self.state = 460
            self.match(bigqueryParser.AS)
            self.state = 461
            self.datatype_name()
            self.state = 462
            self.match(bigqueryParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Column_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def column_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Column_exprContext,0)


        def column_name(self):
            return self.getTypedRuleContext(bigqueryParser.Column_nameContext,0)


        def table_name(self):
            return self.getTypedRuleContext(bigqueryParser.Table_nameContext,0)


        def dataset_name(self):
            return self.getTypedRuleContext(bigqueryParser.Dataset_nameContext,0)


        def project_name(self):
            return self.getTypedRuleContext(bigqueryParser.Project_nameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_column_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumn_expr" ):
                listener.enterColumn_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumn_expr" ):
                listener.exitColumn_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumn_expr" ):
                return visitor.visitColumn_expr(self)
            else:
                return visitor.visitChildren(self)




    def column_expr(self):

        localctx = bigqueryParser.Column_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_column_expr)
        try:
            self.state = 484
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,64,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 464
                self.match(bigqueryParser.T__22)
                self.state = 465
                self.column_expr()
                self.state = 466
                self.match(bigqueryParser.T__22)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 481
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,63,self._ctx)
                if la_ == 1:
                    self.state = 476
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,62,self._ctx)
                    if la_ == 1:
                        self.state = 471
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,61,self._ctx)
                        if la_ == 1:
                            self.state = 468
                            self.project_name()
                            self.state = 469
                            self.match(bigqueryParser.T__3)


                        self.state = 473
                        self.dataset_name()
                        self.state = 474
                        self.match(bigqueryParser.T__3)


                    self.state = 478
                    self.table_name()
                    self.state = 479
                    self.match(bigqueryParser.T__3)


                self.state = 483
                self.column_name()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Except_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EXCEPT(self):
            return self.getToken(bigqueryParser.EXCEPT, 0)

        def column_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Column_nameContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Column_nameContext,i)


        def getRuleIndex(self):
            return bigqueryParser.RULE_except_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExcept_statement" ):
                listener.enterExcept_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExcept_statement" ):
                listener.exitExcept_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExcept_statement" ):
                return visitor.visitExcept_statement(self)
            else:
                return visitor.visitChildren(self)




    def except_statement(self):

        localctx = bigqueryParser.Except_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_except_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            self.match(bigqueryParser.EXCEPT)
            self.state = 487
            self.match(bigqueryParser.T__1)
            self.state = 488
            self.column_name()
            self.state = 493
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==bigqueryParser.T__5:
                self.state = 489
                self.match(bigqueryParser.T__5)
                self.state = 490
                self.column_name()
                self.state = 495
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 496
            self.match(bigqueryParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Replace_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REPLACE(self):
            return self.getToken(bigqueryParser.REPLACE, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.ExprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.ExprContext,i)


        def alias_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Alias_nameContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Alias_nameContext,i)


        def AS(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.AS)
            else:
                return self.getToken(bigqueryParser.AS, i)

        def getRuleIndex(self):
            return bigqueryParser.RULE_replace_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReplace_statement" ):
                listener.enterReplace_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReplace_statement" ):
                listener.exitReplace_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReplace_statement" ):
                return visitor.visitReplace_statement(self)
            else:
                return visitor.visitChildren(self)




    def replace_statement(self):

        localctx = bigqueryParser.Replace_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_replace_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 498
            self.match(bigqueryParser.REPLACE)
            self.state = 499
            self.match(bigqueryParser.T__1)
            self.state = 500
            self.expr(0)
            self.state = 505
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << bigqueryParser.T__1) | (1 << bigqueryParser.T__22) | (1 << bigqueryParser.QUOTE) | (1 << bigqueryParser.DQOUTE) | (1 << bigqueryParser.AS))) != 0) or _la==bigqueryParser.ID:
                self.state = 502
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.AS:
                    self.state = 501
                    self.match(bigqueryParser.AS)


                self.state = 504
                self.alias_name()


            self.state = 507
            self.match(bigqueryParser.T__5)
            self.state = 508
            self.expr(0)
            self.state = 515
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << bigqueryParser.T__1) | (1 << bigqueryParser.T__22) | (1 << bigqueryParser.QUOTE) | (1 << bigqueryParser.DQOUTE) | (1 << bigqueryParser.AS))) != 0) or _la==bigqueryParser.ID:
                self.state = 510
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.AS:
                    self.state = 509
                    self.match(bigqueryParser.AS)


                self.state = 512
                self.alias_name()
                self.state = 517
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 518
            self.match(bigqueryParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Join_typeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INNER(self):
            return self.getToken(bigqueryParser.INNER, 0)

        def CROSS(self):
            return self.getToken(bigqueryParser.CROSS, 0)

        def FULL(self):
            return self.getToken(bigqueryParser.FULL, 0)

        def OUTER(self):
            return self.getToken(bigqueryParser.OUTER, 0)

        def LEFT(self):
            return self.getToken(bigqueryParser.LEFT, 0)

        def RIGHT(self):
            return self.getToken(bigqueryParser.RIGHT, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_join_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoin_type" ):
                listener.enterJoin_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoin_type" ):
                listener.exitJoin_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJoin_type" ):
                return visitor.visitJoin_type(self)
            else:
                return visitor.visitChildren(self)




    def join_type(self):

        localctx = bigqueryParser.Join_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_join_type)
        self._la = 0 # Token type
        try:
            self.state = 534
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.INNER]:
                self.enterOuterAlt(localctx, 1)
                self.state = 520
                self.match(bigqueryParser.INNER)
                pass
            elif token in [bigqueryParser.CROSS]:
                self.enterOuterAlt(localctx, 2)
                self.state = 521
                self.match(bigqueryParser.CROSS)
                pass
            elif token in [bigqueryParser.FULL]:
                self.enterOuterAlt(localctx, 3)
                self.state = 522
                self.match(bigqueryParser.FULL)
                self.state = 524
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.OUTER:
                    self.state = 523
                    self.match(bigqueryParser.OUTER)


                pass
            elif token in [bigqueryParser.LEFT]:
                self.enterOuterAlt(localctx, 4)
                self.state = 526
                self.match(bigqueryParser.LEFT)
                self.state = 528
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.OUTER:
                    self.state = 527
                    self.match(bigqueryParser.OUTER)


                pass
            elif token in [bigqueryParser.RIGHT]:
                self.enterOuterAlt(localctx, 5)
                self.state = 530
                self.match(bigqueryParser.RIGHT)
                self.state = 532
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.OUTER:
                    self.state = 531
                    self.match(bigqueryParser.OUTER)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class On_clauseContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ON(self):
            return self.getToken(bigqueryParser.ON, 0)

        def bool_expression(self):
            return self.getTypedRuleContext(bigqueryParser.Bool_expressionContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_on_clause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOn_clause" ):
                listener.enterOn_clause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOn_clause" ):
                listener.exitOn_clause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOn_clause" ):
                return visitor.visitOn_clause(self)
            else:
                return visitor.visitChildren(self)




    def on_clause(self):

        localctx = bigqueryParser.On_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_on_clause)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 536
            self.match(bigqueryParser.ON)
            self.state = 537
            self.bool_expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Set_opContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UNION(self):
            return self.getToken(bigqueryParser.UNION, 0)

        def ALL(self):
            return self.getToken(bigqueryParser.ALL, 0)

        def DISTINCT(self):
            return self.getToken(bigqueryParser.DISTINCT, 0)

        def INTERSECT(self):
            return self.getToken(bigqueryParser.INTERSECT, 0)

        def EXCEPT(self):
            return self.getToken(bigqueryParser.EXCEPT, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_set_op

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSet_op" ):
                listener.enterSet_op(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSet_op" ):
                listener.exitSet_op(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSet_op" ):
                return visitor.visitSet_op(self)
            else:
                return visitor.visitChildren(self)




    def set_op(self):

        localctx = bigqueryParser.Set_opContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_set_op)
        self._la = 0 # Token type
        try:
            self.state = 547
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.UNION]:
                self.enterOuterAlt(localctx, 1)
                self.state = 539
                self.match(bigqueryParser.UNION)
                self.state = 541
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==bigqueryParser.ALL or _la==bigqueryParser.DISTINCT:
                    self.state = 540
                    _la = self._input.LA(1)
                    if not(_la==bigqueryParser.ALL or _la==bigqueryParser.DISTINCT):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                pass
            elif token in [bigqueryParser.INTERSECT]:
                self.enterOuterAlt(localctx, 2)
                self.state = 543
                self.match(bigqueryParser.INTERSECT)
                self.state = 544
                self.match(bigqueryParser.DISTINCT)
                pass
            elif token in [bigqueryParser.EXCEPT]:
                self.enterOuterAlt(localctx, 3)
                self.state = 545
                self.match(bigqueryParser.EXCEPT)
                self.state = 546
                self.match(bigqueryParser.DISTINCT)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Using_clauseContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def USING(self):
            return self.getToken(bigqueryParser.USING, 0)

        def join_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Join_nameContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Join_nameContext,i)


        def getRuleIndex(self):
            return bigqueryParser.RULE_using_clause

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUsing_clause" ):
                listener.enterUsing_clause(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUsing_clause" ):
                listener.exitUsing_clause(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUsing_clause" ):
                return visitor.visitUsing_clause(self)
            else:
                return visitor.visitChildren(self)




    def using_clause(self):

        localctx = bigqueryParser.Using_clauseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_using_clause)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 549
            self.match(bigqueryParser.USING)
            self.state = 550
            self.match(bigqueryParser.T__1)
            self.state = 551
            self.join_name()
            self.state = 556
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==bigqueryParser.T__5:
                self.state = 552
                self.match(bigqueryParser.T__5)
                self.state = 553
                self.join_name()
                self.state = 558
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 559
            self.match(bigqueryParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bool_expressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(bigqueryParser.ExprContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_bool_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBool_expression" ):
                listener.enterBool_expression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBool_expression" ):
                listener.exitBool_expression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBool_expression" ):
                return visitor.visitBool_expression(self)
            else:
                return visitor.visitChildren(self)




    def bool_expression(self):

        localctx = bigqueryParser.Bool_expressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_bool_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 561
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CountContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(bigqueryParser.NumberContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_count

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCount" ):
                listener.enterCount(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCount" ):
                listener.exitCount(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCount" ):
                return visitor.visitCount(self)
            else:
                return visitor.visitChildren(self)




    def count(self):

        localctx = bigqueryParser.CountContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_count)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 563
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Skip_rowsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(bigqueryParser.NumberContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_skip_rows

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSkip_rows" ):
                listener.enterSkip_rows(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSkip_rows" ):
                listener.exitSkip_rows(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSkip_rows" ):
                return visitor.visitSkip_rows(self)
            else:
                return visitor.visitChildren(self)




    def skip_rows(self):

        localctx = bigqueryParser.Skip_rowsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_skip_rows)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 565
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class With_statementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WITH(self):
            return self.getToken(bigqueryParser.WITH, 0)

        def cte_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Cte_nameContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Cte_nameContext,i)


        def AS(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.AS)
            else:
                return self.getToken(bigqueryParser.AS, i)

        def query_expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(bigqueryParser.Query_exprContext)
            else:
                return self.getTypedRuleContext(bigqueryParser.Query_exprContext,i)


        def getRuleIndex(self):
            return bigqueryParser.RULE_with_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWith_statement" ):
                listener.enterWith_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWith_statement" ):
                listener.exitWith_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWith_statement" ):
                return visitor.visitWith_statement(self)
            else:
                return visitor.visitChildren(self)




    def with_statement(self):

        localctx = bigqueryParser.With_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_with_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 567
            self.match(bigqueryParser.WITH)
            self.state = 568
            self.cte_name()
            self.state = 569
            self.match(bigqueryParser.AS)
            self.state = 570
            self.match(bigqueryParser.T__1)
            self.state = 571
            self.query_expr(0)
            self.state = 572
            self.match(bigqueryParser.T__2)
            self.state = 582
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==bigqueryParser.T__5:
                self.state = 573
                self.match(bigqueryParser.T__5)
                self.state = 574
                self.cte_name()
                self.state = 575
                self.match(bigqueryParser.AS)
                self.state = 576
                self.match(bigqueryParser.T__1)
                self.state = 577
                self.query_expr(0)
                self.state = 578
                self.match(bigqueryParser.T__2)
                self.state = 584
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(bigqueryParser.ID, 0)

        def DQOUTE(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.DQOUTE)
            else:
                return self.getToken(bigqueryParser.DQOUTE, i)

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(bigqueryParser.QUOTE)
            else:
                return self.getToken(bigqueryParser.QUOTE, i)

        def getRuleIndex(self):
            return bigqueryParser.RULE_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterName" ):
                listener.enterName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitName" ):
                listener.exitName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitName" ):
                return visitor.visitName(self)
            else:
                return visitor.visitChildren(self)




    def name(self):

        localctx = bigqueryParser.NameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_name)
        try:
            self.state = 602
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.ID]:
                self.enterOuterAlt(localctx, 1)
                self.state = 585
                self.match(bigqueryParser.ID)
                pass
            elif token in [bigqueryParser.DQOUTE]:
                self.enterOuterAlt(localctx, 2)
                self.state = 586
                self.match(bigqueryParser.DQOUTE)
                self.state = 587
                self.name()
                self.state = 588
                self.match(bigqueryParser.DQOUTE)
                pass
            elif token in [bigqueryParser.T__1]:
                self.enterOuterAlt(localctx, 3)
                self.state = 590
                self.match(bigqueryParser.T__1)
                self.state = 591
                self.name()
                self.state = 592
                self.match(bigqueryParser.T__2)
                pass
            elif token in [bigqueryParser.T__22]:
                self.enterOuterAlt(localctx, 4)
                self.state = 594
                self.match(bigqueryParser.T__22)
                self.state = 595
                self.name()
                self.state = 596
                self.match(bigqueryParser.T__22)
                pass
            elif token in [bigqueryParser.QUOTE]:
                self.enterOuterAlt(localctx, 5)
                self.state = 598
                self.match(bigqueryParser.QUOTE)
                self.state = 599
                self.name()
                self.state = 600
                self.match(bigqueryParser.QUOTE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Alias_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_alias_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAlias_name" ):
                listener.enterAlias_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAlias_name" ):
                listener.exitAlias_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAlias_name" ):
                return visitor.visitAlias_name(self)
            else:
                return visitor.visitChildren(self)




    def alias_name(self):

        localctx = bigqueryParser.Alias_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_alias_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 604
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Column_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_column_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumn_name" ):
                listener.enterColumn_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumn_name" ):
                listener.exitColumn_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumn_name" ):
                return visitor.visitColumn_name(self)
            else:
                return visitor.visitChildren(self)




    def column_name(self):

        localctx = bigqueryParser.Column_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_column_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 606
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Cte_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_cte_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCte_name" ):
                listener.enterCte_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCte_name" ):
                listener.exitCte_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCte_name" ):
                return visitor.visitCte_name(self)
            else:
                return visitor.visitChildren(self)




    def cte_name(self):

        localctx = bigqueryParser.Cte_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_cte_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 608
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dataset_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_dataset_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDataset_name" ):
                listener.enterDataset_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDataset_name" ):
                listener.exitDataset_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDataset_name" ):
                return visitor.visitDataset_name(self)
            else:
                return visitor.visitChildren(self)




    def dataset_name(self):

        localctx = bigqueryParser.Dataset_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_dataset_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 610
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Datatype_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_datatype_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDatatype_name" ):
                listener.enterDatatype_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDatatype_name" ):
                listener.exitDatatype_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDatatype_name" ):
                return visitor.visitDatatype_name(self)
            else:
                return visitor.visitChildren(self)




    def datatype_name(self):

        localctx = bigqueryParser.Datatype_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_datatype_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 612
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def keyword(self):
            return self.getTypedRuleContext(bigqueryParser.KeywordContext,0)


        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_function_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_name" ):
                listener.enterFunction_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_name" ):
                listener.exitFunction_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_name" ):
                return visitor.visitFunction_name(self)
            else:
                return visitor.visitChildren(self)




    def function_name(self):

        localctx = bigqueryParser.Function_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_function_name)
        try:
            self.state = 616
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.ALL, bigqueryParser.AND, bigqueryParser.ANY, bigqueryParser.ARRAY, bigqueryParser.AS, bigqueryParser.ASC, bigqueryParser.ASSERT_ROWS_MODIFIED, bigqueryParser.AT, bigqueryParser.BETWEEN, bigqueryParser.BY, bigqueryParser.CASE, bigqueryParser.CAST, bigqueryParser.COLLATE, bigqueryParser.CONTAINS, bigqueryParser.CREATE, bigqueryParser.CROSS, bigqueryParser.CUBE, bigqueryParser.CURRENT, bigqueryParser.DEFAULT, bigqueryParser.DEFINE, bigqueryParser.DESC, bigqueryParser.DISTINCT, bigqueryParser.ELSE, bigqueryParser.END, bigqueryParser.ENUM, bigqueryParser.ESCAPE, bigqueryParser.EXCEPT, bigqueryParser.EXCLUDE, bigqueryParser.EXISTS, bigqueryParser.EXTRACT, bigqueryParser.FALSE, bigqueryParser.FETCH, bigqueryParser.FOLLOWING, bigqueryParser.FOR, bigqueryParser.FROM, bigqueryParser.FULL, bigqueryParser.GROUP, bigqueryParser.GROUPING, bigqueryParser.GROUPS, bigqueryParser.HASH, bigqueryParser.HAVING, bigqueryParser.IF, bigqueryParser.IGNORE, bigqueryParser.IN, bigqueryParser.INNER, bigqueryParser.INTERSECT, bigqueryParser.INTERVAL, bigqueryParser.INTO, bigqueryParser.IS, bigqueryParser.JOIN, bigqueryParser.LATERAL, bigqueryParser.LEFT, bigqueryParser.LIKE, bigqueryParser.LIMIT, bigqueryParser.LOOKUP, bigqueryParser.MERGE, bigqueryParser.NATURAL, bigqueryParser.NEW, bigqueryParser.NO, bigqueryParser.NOT, bigqueryParser.S_NULL, bigqueryParser.NULLS, bigqueryParser.OF, bigqueryParser.OFFSET, bigqueryParser.ON, bigqueryParser.OR, bigqueryParser.ORDER, bigqueryParser.ORDINAL, bigqueryParser.OUTER, bigqueryParser.OVER, bigqueryParser.PARTITION, bigqueryParser.PRECEDING, bigqueryParser.PROTO, bigqueryParser.RANGE, bigqueryParser.RECURSIVE, bigqueryParser.REPLACE, bigqueryParser.RESPECT, bigqueryParser.RIGHT, bigqueryParser.ROLLUP, bigqueryParser.ROWS, bigqueryParser.SAFE_OFFSET, bigqueryParser.SAFE_ORDINAL, bigqueryParser.SELECT, bigqueryParser.SET, bigqueryParser.SOME, bigqueryParser.SSTRUCT, bigqueryParser.SYSTEM, bigqueryParser.TABLESAMPLE, bigqueryParser.THEN, bigqueryParser.TIME, bigqueryParser.TO, bigqueryParser.TREAT, bigqueryParser.TRUE, bigqueryParser.UNBOUNDED, bigqueryParser.UNION, bigqueryParser.UNNEST, bigqueryParser.USING, bigqueryParser.WHEN, bigqueryParser.WHERE, bigqueryParser.WINDOW, bigqueryParser.WITH, bigqueryParser.WITHIN, bigqueryParser.DAY, bigqueryParser.YEAR, bigqueryParser.MONTH, bigqueryParser.WEEK, bigqueryParser.QUARTER]:
                self.enterOuterAlt(localctx, 1)
                self.state = 614
                self.keyword()
                pass
            elif token in [bigqueryParser.T__1, bigqueryParser.T__22, bigqueryParser.QUOTE, bigqueryParser.DQOUTE, bigqueryParser.ID]:
                self.enterOuterAlt(localctx, 2)
                self.state = 615
                self.name()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Join_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_join_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoin_name" ):
                listener.enterJoin_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoin_name" ):
                listener.exitJoin_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitJoin_name" ):
                return visitor.visitJoin_name(self)
            else:
                return visitor.visitChildren(self)




    def join_name(self):

        localctx = bigqueryParser.Join_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_join_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 618
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Project_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_project_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProject_name" ):
                listener.enterProject_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProject_name" ):
                listener.exitProject_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProject_name" ):
                return visitor.visitProject_name(self)
            else:
                return visitor.visitChildren(self)




    def project_name(self):

        localctx = bigqueryParser.Project_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_project_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 620
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_nameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(bigqueryParser.NameContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_table_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_name" ):
                listener.enterTable_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_name" ):
                listener.exitTable_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_name" ):
                return visitor.visitTable_name(self)
            else:
                return visitor.visitChildren(self)




    def table_name(self):

        localctx = bigqueryParser.Table_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_table_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 622
            self.name()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def table_name(self):
            return self.getTypedRuleContext(bigqueryParser.Table_nameContext,0)


        def dataset_name(self):
            return self.getTypedRuleContext(bigqueryParser.Dataset_nameContext,0)


        def project_name(self):
            return self.getTypedRuleContext(bigqueryParser.Project_nameContext,0)


        def table_expr(self):
            return self.getTypedRuleContext(bigqueryParser.Table_exprContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_table_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_expr" ):
                listener.enterTable_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_expr" ):
                listener.exitTable_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_expr" ):
                return visitor.visitTable_expr(self)
            else:
                return visitor.visitChildren(self)




    def table_expr(self):

        localctx = bigqueryParser.Table_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_table_expr)
        self._la = 0 # Token type
        try:
            self.state = 639
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,82,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 632
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,81,self._ctx)
                if la_ == 1:
                    self.state = 627
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,80,self._ctx)
                    if la_ == 1:
                        self.state = 624
                        self.project_name()
                        self.state = 625
                        _la = self._input.LA(1)
                        if not(_la==bigqueryParser.T__3 or _la==bigqueryParser.T__23):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()


                    self.state = 629
                    self.dataset_name()
                    self.state = 630
                    _la = self._input.LA(1)
                    if not(_la==bigqueryParser.T__3 or _la==bigqueryParser.T__23):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                self.state = 634
                self.table_name()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 635
                self.match(bigqueryParser.T__22)
                self.state = 636
                self.table_expr()
                self.state = 637
                self.match(bigqueryParser.T__22)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integer_type(self):
            return self.getTypedRuleContext(bigqueryParser.Integer_typeContext,0)


        def float_type(self):
            return self.getTypedRuleContext(bigqueryParser.Float_typeContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = bigqueryParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_number)
        try:
            self.state = 643
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.INT]:
                self.enterOuterAlt(localctx, 1)
                self.state = 641
                self.integer_type()
                pass
            elif token in [bigqueryParser.FLOAT]:
                self.enterOuterAlt(localctx, 2)
                self.state = 642
                self.float_type()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Integer_typeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(bigqueryParser.INT, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_integer_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInteger_type" ):
                listener.enterInteger_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInteger_type" ):
                listener.exitInteger_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInteger_type" ):
                return visitor.visitInteger_type(self)
            else:
                return visitor.visitChildren(self)




    def integer_type(self):

        localctx = bigqueryParser.Integer_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_integer_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 645
            self.match(bigqueryParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Float_typeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FLOAT(self):
            return self.getToken(bigqueryParser.FLOAT, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_float_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloat_type" ):
                listener.enterFloat_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloat_type" ):
                listener.exitFloat_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloat_type" ):
                return visitor.visitFloat_type(self)
            else:
                return visitor.visitChildren(self)




    def float_type(self):

        localctx = bigqueryParser.Float_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_float_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 647
            self.match(bigqueryParser.FLOAT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def quoted_string(self):
            return self.getTypedRuleContext(bigqueryParser.Quoted_stringContext,0)


        def triple_quoted_string(self):
            return self.getTypedRuleContext(bigqueryParser.Triple_quoted_stringContext,0)


        def raw_string(self):
            return self.getTypedRuleContext(bigqueryParser.Raw_stringContext,0)


        def byte_string(self):
            return self.getTypedRuleContext(bigqueryParser.Byte_stringContext,0)


        def raw_byte_string(self):
            return self.getTypedRuleContext(bigqueryParser.Raw_byte_stringContext,0)


        def special_string(self):
            return self.getTypedRuleContext(bigqueryParser.Special_stringContext,0)


        def getRuleIndex(self):
            return bigqueryParser.RULE_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)




    def string(self):

        localctx = bigqueryParser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_string)
        try:
            self.state = 655
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [bigqueryParser.QUOTED_STRING]:
                self.enterOuterAlt(localctx, 1)
                self.state = 649
                self.quoted_string()
                pass
            elif token in [bigqueryParser.TRIPLE_QUOTED_STRING]:
                self.enterOuterAlt(localctx, 2)
                self.state = 650
                self.triple_quoted_string()
                pass
            elif token in [bigqueryParser.RAW_STRING]:
                self.enterOuterAlt(localctx, 3)
                self.state = 651
                self.raw_string()
                pass
            elif token in [bigqueryParser.BYTE_STRING]:
                self.enterOuterAlt(localctx, 4)
                self.state = 652
                self.byte_string()
                pass
            elif token in [bigqueryParser.RAW_BYTE_STRING]:
                self.enterOuterAlt(localctx, 5)
                self.state = 653
                self.raw_byte_string()
                pass
            elif token in [bigqueryParser.T__1, bigqueryParser.T__22, bigqueryParser.QUOTE, bigqueryParser.DQOUTE, bigqueryParser.ID]:
                self.enterOuterAlt(localctx, 6)
                self.state = 654
                self.special_string()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Quoted_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTED_STRING(self):
            return self.getToken(bigqueryParser.QUOTED_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_quoted_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuoted_string" ):
                listener.enterQuoted_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuoted_string" ):
                listener.exitQuoted_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuoted_string" ):
                return visitor.visitQuoted_string(self)
            else:
                return visitor.visitChildren(self)




    def quoted_string(self):

        localctx = bigqueryParser.Quoted_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_quoted_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 657
            self.match(bigqueryParser.QUOTED_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Triple_quoted_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRIPLE_QUOTED_STRING(self):
            return self.getToken(bigqueryParser.TRIPLE_QUOTED_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_triple_quoted_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTriple_quoted_string" ):
                listener.enterTriple_quoted_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTriple_quoted_string" ):
                listener.exitTriple_quoted_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTriple_quoted_string" ):
                return visitor.visitTriple_quoted_string(self)
            else:
                return visitor.visitChildren(self)




    def triple_quoted_string(self):

        localctx = bigqueryParser.Triple_quoted_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_triple_quoted_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 659
            self.match(bigqueryParser.TRIPLE_QUOTED_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Raw_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RAW_STRING(self):
            return self.getToken(bigqueryParser.RAW_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_raw_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRaw_string" ):
                listener.enterRaw_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRaw_string" ):
                listener.exitRaw_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRaw_string" ):
                return visitor.visitRaw_string(self)
            else:
                return visitor.visitChildren(self)




    def raw_string(self):

        localctx = bigqueryParser.Raw_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_raw_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 661
            self.match(bigqueryParser.RAW_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Byte_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BYTE_STRING(self):
            return self.getToken(bigqueryParser.BYTE_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_byte_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterByte_string" ):
                listener.enterByte_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitByte_string" ):
                listener.exitByte_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitByte_string" ):
                return visitor.visitByte_string(self)
            else:
                return visitor.visitChildren(self)




    def byte_string(self):

        localctx = bigqueryParser.Byte_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_byte_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 663
            self.match(bigqueryParser.BYTE_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Raw_byte_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RAW_BYTE_STRING(self):
            return self.getToken(bigqueryParser.RAW_BYTE_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_raw_byte_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRaw_byte_string" ):
                listener.enterRaw_byte_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRaw_byte_string" ):
                listener.exitRaw_byte_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRaw_byte_string" ):
                return visitor.visitRaw_byte_string(self)
            else:
                return visitor.visitChildren(self)




    def raw_byte_string(self):

        localctx = bigqueryParser.Raw_byte_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_raw_byte_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 665
            self.match(bigqueryParser.RAW_BYTE_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Special_stringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def datatype_name(self):
            return self.getTypedRuleContext(bigqueryParser.Datatype_nameContext,0)


        def QUOTED_STRING(self):
            return self.getToken(bigqueryParser.QUOTED_STRING, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_special_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSpecial_string" ):
                listener.enterSpecial_string(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSpecial_string" ):
                listener.exitSpecial_string(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSpecial_string" ):
                return visitor.visitSpecial_string(self)
            else:
                return visitor.visitChildren(self)




    def special_string(self):

        localctx = bigqueryParser.Special_stringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_special_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 667
            self.datatype_name()
            self.state = 668
            self.match(bigqueryParser.QUOTED_STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeywordContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALL(self):
            return self.getToken(bigqueryParser.ALL, 0)

        def AND(self):
            return self.getToken(bigqueryParser.AND, 0)

        def ANY(self):
            return self.getToken(bigqueryParser.ANY, 0)

        def ARRAY(self):
            return self.getToken(bigqueryParser.ARRAY, 0)

        def AS(self):
            return self.getToken(bigqueryParser.AS, 0)

        def ASC(self):
            return self.getToken(bigqueryParser.ASC, 0)

        def ASSERT_ROWS_MODIFIED(self):
            return self.getToken(bigqueryParser.ASSERT_ROWS_MODIFIED, 0)

        def AT(self):
            return self.getToken(bigqueryParser.AT, 0)

        def BETWEEN(self):
            return self.getToken(bigqueryParser.BETWEEN, 0)

        def BY(self):
            return self.getToken(bigqueryParser.BY, 0)

        def CASE(self):
            return self.getToken(bigqueryParser.CASE, 0)

        def CAST(self):
            return self.getToken(bigqueryParser.CAST, 0)

        def COLLATE(self):
            return self.getToken(bigqueryParser.COLLATE, 0)

        def CONTAINS(self):
            return self.getToken(bigqueryParser.CONTAINS, 0)

        def CREATE(self):
            return self.getToken(bigqueryParser.CREATE, 0)

        def CROSS(self):
            return self.getToken(bigqueryParser.CROSS, 0)

        def CUBE(self):
            return self.getToken(bigqueryParser.CUBE, 0)

        def CURRENT(self):
            return self.getToken(bigqueryParser.CURRENT, 0)

        def DEFAULT(self):
            return self.getToken(bigqueryParser.DEFAULT, 0)

        def DEFINE(self):
            return self.getToken(bigqueryParser.DEFINE, 0)

        def DESC(self):
            return self.getToken(bigqueryParser.DESC, 0)

        def DISTINCT(self):
            return self.getToken(bigqueryParser.DISTINCT, 0)

        def ELSE(self):
            return self.getToken(bigqueryParser.ELSE, 0)

        def END(self):
            return self.getToken(bigqueryParser.END, 0)

        def ENUM(self):
            return self.getToken(bigqueryParser.ENUM, 0)

        def ESCAPE(self):
            return self.getToken(bigqueryParser.ESCAPE, 0)

        def EXCEPT(self):
            return self.getToken(bigqueryParser.EXCEPT, 0)

        def EXCLUDE(self):
            return self.getToken(bigqueryParser.EXCLUDE, 0)

        def EXISTS(self):
            return self.getToken(bigqueryParser.EXISTS, 0)

        def EXTRACT(self):
            return self.getToken(bigqueryParser.EXTRACT, 0)

        def FALSE(self):
            return self.getToken(bigqueryParser.FALSE, 0)

        def FETCH(self):
            return self.getToken(bigqueryParser.FETCH, 0)

        def FOLLOWING(self):
            return self.getToken(bigqueryParser.FOLLOWING, 0)

        def FOR(self):
            return self.getToken(bigqueryParser.FOR, 0)

        def FROM(self):
            return self.getToken(bigqueryParser.FROM, 0)

        def FULL(self):
            return self.getToken(bigqueryParser.FULL, 0)

        def GROUP(self):
            return self.getToken(bigqueryParser.GROUP, 0)

        def GROUPING(self):
            return self.getToken(bigqueryParser.GROUPING, 0)

        def GROUPS(self):
            return self.getToken(bigqueryParser.GROUPS, 0)

        def HASH(self):
            return self.getToken(bigqueryParser.HASH, 0)

        def HAVING(self):
            return self.getToken(bigqueryParser.HAVING, 0)

        def IF(self):
            return self.getToken(bigqueryParser.IF, 0)

        def IGNORE(self):
            return self.getToken(bigqueryParser.IGNORE, 0)

        def IN(self):
            return self.getToken(bigqueryParser.IN, 0)

        def INNER(self):
            return self.getToken(bigqueryParser.INNER, 0)

        def INTERSECT(self):
            return self.getToken(bigqueryParser.INTERSECT, 0)

        def INTERVAL(self):
            return self.getToken(bigqueryParser.INTERVAL, 0)

        def INTO(self):
            return self.getToken(bigqueryParser.INTO, 0)

        def IS(self):
            return self.getToken(bigqueryParser.IS, 0)

        def JOIN(self):
            return self.getToken(bigqueryParser.JOIN, 0)

        def LATERAL(self):
            return self.getToken(bigqueryParser.LATERAL, 0)

        def LEFT(self):
            return self.getToken(bigqueryParser.LEFT, 0)

        def LIKE(self):
            return self.getToken(bigqueryParser.LIKE, 0)

        def LIMIT(self):
            return self.getToken(bigqueryParser.LIMIT, 0)

        def LOOKUP(self):
            return self.getToken(bigqueryParser.LOOKUP, 0)

        def MERGE(self):
            return self.getToken(bigqueryParser.MERGE, 0)

        def NATURAL(self):
            return self.getToken(bigqueryParser.NATURAL, 0)

        def NEW(self):
            return self.getToken(bigqueryParser.NEW, 0)

        def NO(self):
            return self.getToken(bigqueryParser.NO, 0)

        def NOT(self):
            return self.getToken(bigqueryParser.NOT, 0)

        def S_NULL(self):
            return self.getToken(bigqueryParser.S_NULL, 0)

        def NULLS(self):
            return self.getToken(bigqueryParser.NULLS, 0)

        def OF(self):
            return self.getToken(bigqueryParser.OF, 0)

        def OFFSET(self):
            return self.getToken(bigqueryParser.OFFSET, 0)

        def ON(self):
            return self.getToken(bigqueryParser.ON, 0)

        def OR(self):
            return self.getToken(bigqueryParser.OR, 0)

        def ORDER(self):
            return self.getToken(bigqueryParser.ORDER, 0)

        def ORDINAL(self):
            return self.getToken(bigqueryParser.ORDINAL, 0)

        def OUTER(self):
            return self.getToken(bigqueryParser.OUTER, 0)

        def OVER(self):
            return self.getToken(bigqueryParser.OVER, 0)

        def PARTITION(self):
            return self.getToken(bigqueryParser.PARTITION, 0)

        def PRECEDING(self):
            return self.getToken(bigqueryParser.PRECEDING, 0)

        def PROTO(self):
            return self.getToken(bigqueryParser.PROTO, 0)

        def RANGE(self):
            return self.getToken(bigqueryParser.RANGE, 0)

        def RECURSIVE(self):
            return self.getToken(bigqueryParser.RECURSIVE, 0)

        def REPLACE(self):
            return self.getToken(bigqueryParser.REPLACE, 0)

        def RESPECT(self):
            return self.getToken(bigqueryParser.RESPECT, 0)

        def RIGHT(self):
            return self.getToken(bigqueryParser.RIGHT, 0)

        def ROLLUP(self):
            return self.getToken(bigqueryParser.ROLLUP, 0)

        def ROWS(self):
            return self.getToken(bigqueryParser.ROWS, 0)

        def SAFE_OFFSET(self):
            return self.getToken(bigqueryParser.SAFE_OFFSET, 0)

        def SAFE_ORDINAL(self):
            return self.getToken(bigqueryParser.SAFE_ORDINAL, 0)

        def SELECT(self):
            return self.getToken(bigqueryParser.SELECT, 0)

        def SET(self):
            return self.getToken(bigqueryParser.SET, 0)

        def SOME(self):
            return self.getToken(bigqueryParser.SOME, 0)

        def SSTRUCT(self):
            return self.getToken(bigqueryParser.SSTRUCT, 0)

        def SYSTEM(self):
            return self.getToken(bigqueryParser.SYSTEM, 0)

        def TABLESAMPLE(self):
            return self.getToken(bigqueryParser.TABLESAMPLE, 0)

        def THEN(self):
            return self.getToken(bigqueryParser.THEN, 0)

        def TIME(self):
            return self.getToken(bigqueryParser.TIME, 0)

        def TO(self):
            return self.getToken(bigqueryParser.TO, 0)

        def TREAT(self):
            return self.getToken(bigqueryParser.TREAT, 0)

        def TRUE(self):
            return self.getToken(bigqueryParser.TRUE, 0)

        def UNBOUNDED(self):
            return self.getToken(bigqueryParser.UNBOUNDED, 0)

        def UNION(self):
            return self.getToken(bigqueryParser.UNION, 0)

        def UNNEST(self):
            return self.getToken(bigqueryParser.UNNEST, 0)

        def USING(self):
            return self.getToken(bigqueryParser.USING, 0)

        def WHEN(self):
            return self.getToken(bigqueryParser.WHEN, 0)

        def WHERE(self):
            return self.getToken(bigqueryParser.WHERE, 0)

        def WINDOW(self):
            return self.getToken(bigqueryParser.WINDOW, 0)

        def WITH(self):
            return self.getToken(bigqueryParser.WITH, 0)

        def WITHIN(self):
            return self.getToken(bigqueryParser.WITHIN, 0)

        def DAY(self):
            return self.getToken(bigqueryParser.DAY, 0)

        def YEAR(self):
            return self.getToken(bigqueryParser.YEAR, 0)

        def MONTH(self):
            return self.getToken(bigqueryParser.MONTH, 0)

        def WEEK(self):
            return self.getToken(bigqueryParser.WEEK, 0)

        def QUARTER(self):
            return self.getToken(bigqueryParser.QUARTER, 0)

        def getRuleIndex(self):
            return bigqueryParser.RULE_keyword

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyword" ):
                listener.enterKeyword(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyword" ):
                listener.exitKeyword(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitKeyword" ):
                return visitor.visitKeyword(self)
            else:
                return visitor.visitChildren(self)




    def keyword(self):

        localctx = bigqueryParser.KeywordContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_keyword)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 670
            _la = self._input.LA(1)
            if not(((((_la - 30)) & ~0x3f) == 0 and ((1 << (_la - 30)) & ((1 << (bigqueryParser.ALL - 30)) | (1 << (bigqueryParser.AND - 30)) | (1 << (bigqueryParser.ANY - 30)) | (1 << (bigqueryParser.ARRAY - 30)) | (1 << (bigqueryParser.AS - 30)) | (1 << (bigqueryParser.ASC - 30)) | (1 << (bigqueryParser.ASSERT_ROWS_MODIFIED - 30)) | (1 << (bigqueryParser.AT - 30)) | (1 << (bigqueryParser.BETWEEN - 30)) | (1 << (bigqueryParser.BY - 30)) | (1 << (bigqueryParser.CASE - 30)) | (1 << (bigqueryParser.CAST - 30)) | (1 << (bigqueryParser.COLLATE - 30)) | (1 << (bigqueryParser.CONTAINS - 30)) | (1 << (bigqueryParser.CREATE - 30)) | (1 << (bigqueryParser.CROSS - 30)) | (1 << (bigqueryParser.CUBE - 30)) | (1 << (bigqueryParser.CURRENT - 30)) | (1 << (bigqueryParser.DEFAULT - 30)) | (1 << (bigqueryParser.DEFINE - 30)) | (1 << (bigqueryParser.DESC - 30)) | (1 << (bigqueryParser.DISTINCT - 30)) | (1 << (bigqueryParser.ELSE - 30)) | (1 << (bigqueryParser.END - 30)) | (1 << (bigqueryParser.ENUM - 30)) | (1 << (bigqueryParser.ESCAPE - 30)) | (1 << (bigqueryParser.EXCEPT - 30)) | (1 << (bigqueryParser.EXCLUDE - 30)) | (1 << (bigqueryParser.EXISTS - 30)) | (1 << (bigqueryParser.EXTRACT - 30)) | (1 << (bigqueryParser.FALSE - 30)) | (1 << (bigqueryParser.FETCH - 30)) | (1 << (bigqueryParser.FOLLOWING - 30)) | (1 << (bigqueryParser.FOR - 30)) | (1 << (bigqueryParser.FROM - 30)) | (1 << (bigqueryParser.FULL - 30)) | (1 << (bigqueryParser.GROUP - 30)) | (1 << (bigqueryParser.GROUPING - 30)) | (1 << (bigqueryParser.GROUPS - 30)) | (1 << (bigqueryParser.HASH - 30)) | (1 << (bigqueryParser.HAVING - 30)) | (1 << (bigqueryParser.IF - 30)) | (1 << (bigqueryParser.IGNORE - 30)) | (1 << (bigqueryParser.IN - 30)) | (1 << (bigqueryParser.INNER - 30)) | (1 << (bigqueryParser.INTERSECT - 30)) | (1 << (bigqueryParser.INTERVAL - 30)) | (1 << (bigqueryParser.INTO - 30)) | (1 << (bigqueryParser.IS - 30)) | (1 << (bigqueryParser.JOIN - 30)) | (1 << (bigqueryParser.LATERAL - 30)) | (1 << (bigqueryParser.LEFT - 30)) | (1 << (bigqueryParser.LIKE - 30)) | (1 << (bigqueryParser.LIMIT - 30)) | (1 << (bigqueryParser.LOOKUP - 30)) | (1 << (bigqueryParser.MERGE - 30)) | (1 << (bigqueryParser.NATURAL - 30)) | (1 << (bigqueryParser.NEW - 30)) | (1 << (bigqueryParser.NO - 30)) | (1 << (bigqueryParser.NOT - 30)) | (1 << (bigqueryParser.S_NULL - 30)) | (1 << (bigqueryParser.NULLS - 30)) | (1 << (bigqueryParser.OF - 30)) | (1 << (bigqueryParser.OFFSET - 30)))) != 0) or ((((_la - 94)) & ~0x3f) == 0 and ((1 << (_la - 94)) & ((1 << (bigqueryParser.ON - 94)) | (1 << (bigqueryParser.OR - 94)) | (1 << (bigqueryParser.ORDER - 94)) | (1 << (bigqueryParser.ORDINAL - 94)) | (1 << (bigqueryParser.OUTER - 94)) | (1 << (bigqueryParser.OVER - 94)) | (1 << (bigqueryParser.PARTITION - 94)) | (1 << (bigqueryParser.PRECEDING - 94)) | (1 << (bigqueryParser.PROTO - 94)) | (1 << (bigqueryParser.RANGE - 94)) | (1 << (bigqueryParser.RECURSIVE - 94)) | (1 << (bigqueryParser.REPLACE - 94)) | (1 << (bigqueryParser.RESPECT - 94)) | (1 << (bigqueryParser.RIGHT - 94)) | (1 << (bigqueryParser.ROLLUP - 94)) | (1 << (bigqueryParser.ROWS - 94)) | (1 << (bigqueryParser.SAFE_OFFSET - 94)) | (1 << (bigqueryParser.SAFE_ORDINAL - 94)) | (1 << (bigqueryParser.SELECT - 94)) | (1 << (bigqueryParser.SET - 94)) | (1 << (bigqueryParser.SOME - 94)) | (1 << (bigqueryParser.SSTRUCT - 94)) | (1 << (bigqueryParser.SYSTEM - 94)) | (1 << (bigqueryParser.TABLESAMPLE - 94)) | (1 << (bigqueryParser.THEN - 94)) | (1 << (bigqueryParser.TIME - 94)) | (1 << (bigqueryParser.TO - 94)) | (1 << (bigqueryParser.TREAT - 94)) | (1 << (bigqueryParser.TRUE - 94)) | (1 << (bigqueryParser.UNBOUNDED - 94)) | (1 << (bigqueryParser.UNION - 94)) | (1 << (bigqueryParser.UNNEST - 94)) | (1 << (bigqueryParser.USING - 94)) | (1 << (bigqueryParser.WHEN - 94)) | (1 << (bigqueryParser.WHERE - 94)) | (1 << (bigqueryParser.WINDOW - 94)) | (1 << (bigqueryParser.WITH - 94)) | (1 << (bigqueryParser.WITHIN - 94)) | (1 << (bigqueryParser.DAY - 94)) | (1 << (bigqueryParser.YEAR - 94)) | (1 << (bigqueryParser.MONTH - 94)) | (1 << (bigqueryParser.WEEK - 94)) | (1 << (bigqueryParser.QUARTER - 94)))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.query_expr_sempred
        self._predicates[4] = self.from_item_sempred
        self._predicates[11] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def query_expr_sempred(self, localctx:Query_exprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 1)
         

    def from_item_sempred(self, localctx:From_itemContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 19)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 18)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 15)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 14)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 12:
                return self.precpred(self._ctx, 10)
         




