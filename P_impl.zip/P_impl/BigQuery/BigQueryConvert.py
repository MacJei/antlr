import re
import util
from OutputScript import OutputScript


class BigQueryConvert():

    class ConvDataStore():
        def __init__(self, cntx, output):
            self.cntx = cntx
            self.output = output
            self.table_df_map = {}
            self.var_datatype = {}
            self.union_chklist = []
            self.with_tables = []
            self.cd_idx = 0
            self.tabs = 0
            self.trnc_tables = ''
            self.rtn_parm_str = ''
            self.sp_name = ''
            
    def __init__(self, cntx, input):
        self.cntx = cntx
        self.input = input

        #make output filename
        if '.' in input.fname:
            out_fname = input.fname[::-1].split('.',1)[1][::-1] + '.athena.sql'
        else:
            out_fname = input.fname + '.athena.sql'
        #make output script object
        self.output = OutputScript(cntx, out_fname)
        
        #create data store for conversion
        self.cnv_ds = BigQueryConvert.ConvDataStore(self.cntx, self.output)
        self.cnv_ds.table_df_map, self.cnv_ds.union_chklist = self.scanScript()        
        
        
    #create list of all participating tables in the script and derive data frame name    
    def scanScript(self):
        table_df_map = {}
        union_chklist = []

        return table_df_map, list(set(union_chklist))


    #adds code to create initial dataframes based on execution platform and target database
    def addPlatformRead(self):
        pass
        
    #adds code to create initial dataframes based on execution platform and target database
    def addPlatformWrite(self):
        pass
        
    #starts conversion process for given context
    def convert(self):
        
        #self.addPlatformRead()

        for stmt in self.input.statements:
            cnv_code = stmt.convStatement(self.cnv_ds)
            if len(cnv_code) > 0:
                self.output.addCode(cnv_code)
                self.cnv_ds.cd_idx += 1

        #self.addPlatformWrite()
        
        return self.output
        