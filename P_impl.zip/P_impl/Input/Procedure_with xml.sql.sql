USE [ICM_Stage]
GO

/****** Object:  StoredProcedure [ICMTRANS_PEACETX].[usp_UpdateMasterContractLookup]    Script Date: 9/24/2019 12:17:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* **************************************************************
** Procedure Name: ICMTRANS_PEACETX.usp_UpdateMasterContractLookup 951
** 
** Description:
**	
** Parameters:
**
** Returns:
**
** Change History:
** Date		Author		Changes Made
** ----------	---------------	----------------------------
** 			
*************************************************************** */
CREATE PROCEDURE [ICMTRANS_PEACETX].[usp_UpdateMasterContractLookup] (
	@LoadControlID		int 
) AS BEGIN

	SET NOCOUNT ON;
	DECLARE @iRowsUpdated int;
	
	UPDATE	lkp
	SET	lkp.LOADCONTROLDELETEID		= @LoadControlID
	FROM	ICM_Stage.ICMTRANS_PEACETX.vw_MasterContractLookup lkp 
	LEFT	JOIN (
			SELECT	cdpt.DEBTORNUM,
				cdpt.PREMNUM,
				cdpt.SUPPLYREQDATE
			FROM	ICM_Stage.ICMSTAGE_PEACETX.PM_E_CONSPREM_TB cdpt
			GROUP BY
				cdpt.DEBTORNUM,
				cdpt.PREMNUM,
				cdpt.SUPPLYREQDATE
		) AS cdpt
		ON	lkp.DEBTORNUM = cdpt.DEBTORNUM
		AND	lkp.PREMNUM = cdpt.PREMNUM
		AND	lkp.SUPPLYREQDATE = cdpt.SUPPLYREQDATE
	WHERE	cdpt.DEBTORNUM		IS NULL
	  AND	lkp.LOADCONTROLDELETEID	IS NULL;

	BEGIN TRAN;

	BEGIN TRY;
		-- *******************************************************
		-- Update the change field for the master contract table
		--	for records that already exist in the source
		--	table.
		-- *******************************************************
		UPDATE	A        
		SET	Changed = 1,
			A.LOADCONTROLUPDATEID = B.LOADCONTROLCREATEID,
			A.LOADCONTROLDELETEID = NULL     
		FROM	ICMTRANS_PEACETX.vw_MasterContractLookup A 
		INNER	JOIN ICMSTAGE_PEACETX.PM_E_CONSPREM_TB_TEMP B 
			ON	A.[DEBTORNUM] = B.[DEBTORNUM]
			AND	A.[PREMNUM] = B.[PREMNUM]
			AND	A.SUPPLYREQDATE = B.SUPPLYREQDATE
		WHERE	A.CIS_ID	= 1  --Update only PEACETX 
		  AND	A.Changed	= 0

		-- *******************************************************
		-- Insert new records into the Lookup master contract
		--	table for records that are not already present.
		-- *******************************************************
		IF NOT EXISTS (
			SELECT	*
			FROM	LOOKUP.MASTERCONTRACT
			WHERE	CIS_ID		= 1
		) BEGIN
			INSERT INTO [LOOKUP].[MASTERCONTRACT] (
				[Key],
				[Changed],
				[CIS_ID],
				LOADCONTROLCREATEID,
				LOADCONTROLUPDATEID)
			SELECT	DISTINCT 
				'<Key>'
					+ '<DEBTORNUM>'+CONVERT(VARCHAR(20),A.DEBTORNUM)+'</DEBTORNUM>'
					+'<PREMNUM>'+CONVERT(VARCHAR(20),A.PREMNUM)+'</PREMNUM>'
					+'<SUPPLYREQDATE>'+CONVERT(VARCHAR(20),A.SUPPLYREQDATE)+'</SUPPLYREQDATE>'
				+'</Key>',
				1 AS Changed,
				1 AS CIS_ID,
				A.LOADCONTROLCREATEID,
				A.LOADCONTROLCREATEID
			FROM	ICMSTAGE_PEACETX.PM_E_CONSPREM_TB A
			LEFT	JOIN ICMTRANS_PEACETX.vw_MasterContractLookup B
				ON	A.[DEBTORNUM] = B.[DEBTORNUM]
				AND	A.[PREMNUM] = B.[PREMNUM]
				AND	A.SUPPLYREQDATE = B.SUPPLYREQDATE 
			WHERE	B.[DEBTORNUM]		IS NULL;
		END ELSE BEGIN
			INSERT INTO [LOOKUP].[MASTERCONTRACT] (
				[Key],
				[Changed],
				[CIS_ID],
				LOADCONTROLCREATEID,
				LOADCONTROLUPDATEID)
			SELECT	DISTINCT 
				'<Key>'
					+ '<DEBTORNUM>'+CONVERT(VARCHAR(20),A.DEBTORNUM)+'</DEBTORNUM>'
					+'<PREMNUM>'+CONVERT(VARCHAR(20),A.PREMNUM)+'</PREMNUM>'
					+'<SUPPLYREQDATE>'+CONVERT(VARCHAR(20),A.SUPPLYREQDATE)+'</SUPPLYREQDATE>'
				+'</Key>',
				1 AS Changed,
				1 AS CIS_ID,
				A.LOADCONTROLCREATEID,
				A.LOADCONTROLCREATEID
			FROM	ICMSTAGE_PEACETX.PM_E_CONSPREM_TB_TEMP A
			LEFT	JOIN ICMTRANS_PEACETX.vw_MasterContractLookup B
				ON	A.[DEBTORNUM] = B.[DEBTORNUM]
				AND	A.[PREMNUM] = B.[PREMNUM]
				AND	A.SUPPLYREQDATE = B.SUPPLYREQDATE 
			WHERE	B.[DEBTORNUM]		IS NULL;
		END
		
		SET @iRowsUpdated = @@ROWCOUNT;
		
		COMMIT TRAN;
	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT	@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();
			
		ROLLBACK TRANSACTION;

		-- Use RAISERROR inside the CATCH block to return error
		-- information about the original error that caused
		-- execution to jump to the CATCH block.
		RAISERROR (
			@ErrorMessage, -- Message text.
			@ErrorSeverity, -- Severity.
			@ErrorState -- State.
		);
	END CATCH
	RETURN @iRowsUpdated;             
END

GO


