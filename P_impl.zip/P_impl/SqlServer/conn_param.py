#connction parameters
s3_source_bucket = ''
s3_target_bucket = ''

#If AWS Glue used as execution platform
catalog_db = ''






#DO NOT CHANGE
 
#Global dictionary to store original table data frame
org_df = {}

#Global dictionary to store modified table data frame
mod_df = {}